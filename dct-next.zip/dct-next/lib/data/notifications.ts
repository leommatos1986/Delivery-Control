import { notifications } from "./store";
import type { Notification } from "@/types";
export const listNotifications = (): Notification[] => notifications;
