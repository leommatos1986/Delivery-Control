import { workflowRules } from "./store";
import type { WorkflowRule } from "@/types";
export const listWorkflowRules = (): WorkflowRule[] => workflowRules;
export const updateWorkflowRule = (
  id: string, patch: Partial<WorkflowRule>
): WorkflowRule | null => {
  const r = workflowRules.find((r) => r.id === id);
  if (!r) return null;
  Object.assign(r, patch); return r;
};
