import { users } from "./store";
import type { User } from "@/types";

export const listUsers = (): User[] => users;

export const getUser = (id: string): User | undefined =>
  users.find((u) => u.id === id);

export const createUser = (
  u: Omit<User, "id"> & Partial<Pick<User, "id">>
): User => {
  const newUser: User = { id: u.id ?? "u_" + Date.now(), ...u } as User;
  users.push(newUser);
  return newUser;
};

export const updateUser = (id: string, patch: Partial<User>): User | null => {
  const u = getUser(id);
  if (!u) return null;
  Object.assign(u, patch);
  return u;
};

export const deleteUser = (id: string): boolean => {
  const idx = users.findIndex((u) => u.id === id);
  if (idx < 0) return false;
  users.splice(idx, 1);
  return true;
};

/** Only internal consultants with valid capacity (excludes external stakeholders
 *  and deactivated users) — used everywhere utilization is computed. */
export const internalUsers = (): User[] =>
  users.filter((u) => !u.external && u.cap > 0 && u.status !== "inactive");

/** Safe utilization ratio — never returns Infinity or NaN. */
export const safeUtilPct = (u: User | undefined): number =>
  u && u.cap > 0 ? u.actual / u.cap : 0;
