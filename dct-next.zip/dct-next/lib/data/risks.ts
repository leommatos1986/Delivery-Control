import { risks } from "./store";
import type { Risk } from "@/types";

export const listRisks = (): Risk[] => risks;
export const getRisk = (id: string): Risk | undefined => risks.find((r) => r.id === id);
export const listRisksByProject = (pid: string): Risk[] => risks.filter((r) => r.pid === pid);
export const createRisk = (r: Risk): Risk => { risks.unshift(r); return r; };
export const updateRisk = (id: string, patch: Partial<Risk>): Risk | null => {
  const r = getRisk(id); if (!r) return null;
  Object.assign(r, patch); return r;
};
export const deleteRisk = (id: string): boolean => {
  const idx = risks.findIndex((r) => r.id === id);
  if (idx < 0) return false; risks.splice(idx, 1); return true;
};
export const nextRiskId = (): string => {
  const max = risks.reduce((m, r) => {
    const n = parseInt((r.id.match(/\d+/) || ["0"])[0]) || 0;
    return n > m ? n : m;
  }, 0);
  return "R-" + String(max + 1).padStart(3, "0");
};
