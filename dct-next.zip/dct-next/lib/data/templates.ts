import { templates } from "./store";
import type { Template } from "@/types";

export const listTemplates = (): Template[] => templates;
export const getTemplate = (id: string): Template | undefined => templates.find((t) => t.id === id);
export const createTemplate = (t: Template): Template => { templates.push(t); return t; };
export const updateTemplate = (id: string, patch: Partial<Template>): Template | null => {
  const t = getTemplate(id); if (!t) return null;
  Object.assign(t, patch); return t;
};
export const deleteTemplate = (id: string): boolean => {
  const idx = templates.findIndex((t) => t.id === id);
  if (idx < 0) return false; templates.splice(idx, 1); return true;
};
