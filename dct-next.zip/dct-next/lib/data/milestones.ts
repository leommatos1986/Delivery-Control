import { milestones } from "./store";
import type { Milestone } from "@/types";

export const listMilestones = (): Milestone[] => milestones;
export const getMilestone = (id: string): Milestone | undefined => milestones.find((m) => m.id === id);
export const listMilestonesByProject = (pid: string): Milestone[] => milestones.filter((m) => m.pid === pid);
export const createMilestone = (m: Milestone): Milestone => { milestones.push(m); return m; };
export const updateMilestone = (id: string, patch: Partial<Milestone>): Milestone | null => {
  const m = getMilestone(id); if (!m) return null;
  Object.assign(m, patch); return m;
};
export const deleteMilestone = (id: string): boolean => {
  const idx = milestones.findIndex((m) => m.id === id);
  if (idx < 0) return false; milestones.splice(idx, 1); return true;
};
