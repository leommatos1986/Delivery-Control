import { projects } from "./store";
import type { Project } from "@/types";

export const listProjects = (): Project[] => projects;
export const getProject = (id: string): Project | undefined =>
  projects.find((p) => p.id === id);
export const createProject = (p: Project): Project => {
  projects.push(p);
  return p;
};
export const updateProject = (id: string, patch: Partial<Project>): Project | null => {
  const p = getProject(id);
  if (!p) return null;
  Object.assign(p, patch);
  return p;
};
export const deleteProject = (id: string): boolean => {
  const idx = projects.findIndex((p) => p.id === id);
  if (idx < 0) return false;
  projects.splice(idx, 1);
  return true;
};

/** Convenience selector: projects filtered by client (or "all"). */
export const listProjectsByClient = (clientId: string): Project[] =>
  clientId === "all"
    ? projects
    : projects.filter((p) => p.clientId === clientId);
