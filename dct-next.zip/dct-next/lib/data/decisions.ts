import { decisions } from "./store";
import type { Decision } from "@/types";

export const listDecisions = (): Decision[] => decisions;
export const getDecision = (id: string): Decision | undefined => decisions.find((d) => d.id === id);
export const listDecisionsByProject = (pid: string): Decision[] => decisions.filter((d) => d.pid === pid);
export const createDecision = (d: Decision): Decision => { decisions.unshift(d); return d; };
export const updateDecision = (id: string, patch: Partial<Decision>): Decision | null => {
  const d = getDecision(id); if (!d) return null;
  Object.assign(d, patch); return d;
};
export const deleteDecision = (id: string): boolean => {
  const idx = decisions.findIndex((d) => d.id === id);
  if (idx < 0) return false; decisions.splice(idx, 1); return true;
};
export const nextDecisionId = (): string => {
  const max = decisions.reduce((m, d) => {
    const n = parseInt((d.id.match(/\d+/) || ["0"])[0]) || 0;
    return n > m ? n : m;
  }, 0);
  return "D-" + String(max + 1).padStart(3, "0");
};
