import { activities, activityDetails } from "./store";
import { getUser } from "./users";
import { getProject } from "./projects";
import { getClient } from "./clients";
import type { Activity, ActivityDetail } from "@/types";

export const listActivities = (): Activity[] => activities;

export const getActivity = (id: string): Activity | undefined =>
  activities.find((a) => a.id === id);

export const listActivitiesByProject = (pid: string): Activity[] =>
  activities.filter((a) => a.pid === pid);

export const createActivity = (a: Activity): Activity => {
  activities.push(a);
  return a;
};

export const updateActivity = (id: string, patch: Partial<Activity>): Activity | null => {
  const a = getActivity(id);
  if (!a) return null;
  Object.assign(a, patch);
  return a;
};

export const deleteActivity = (id: string): boolean => {
  const idx = activities.findIndex((a) => a.id === id);
  if (idx < 0) return false;
  activities.splice(idx, 1);
  delete activityDetails[id];
  return true;
};

/**
 * Lazily build a rich detail (history / comments / audit / hours / attachments)
 * for one activity. Deterministic — same input yields same output within a
 * session, so switching between drawer tabs is stable.
 */
export const getActivityDetail = (id: string): ActivityDetail | null => {
  if (activityDetails[id]) return activityDetails[id];
  const a = getActivity(id);
  if (!a) return null;

  const seed = id.split("").reduce((s, c) => s + c.charCodeAt(0), 0);
  const rnd = (n: number) => Math.abs(Math.sin(seed * n)) * 100;
  const owner = getUser(a.ownerId);
  const project = getProject(a.pid);
  const now = new Date("2026-09-02T14:00:00");
  const daysAgo = (d: number) => new Date(now.getTime() - d * 86400000);

  const subs = [
    "Levantamento inicial",
    "Documentação de premissas",
    "Configuração",
    "Validação interna",
    "Sign-off do key-user",
  ];
  const subacts = subs.slice(0, Math.max(2, Math.round(rnd(1) / 22))).map((s, i) => ({
    id: id + "_s" + i,
    text: s,
    done: a.status === "done" || (i < Math.round(rnd(2) / 33) && a.status !== "backlog"),
    who: owner?.name || "—",
  }));

  const comments: ActivityDetail["comments"] = [
    { who: "system", txt: "Atividade criada a partir do template SAP Activate", ts: daysAgo(14) },
  ];
  const history: ActivityDetail["history"] = [
    { from: null, to: "backlog", by: "Sistema", ts: daysAgo(14), note: "Criada" },
  ];
  const audit: ActivityDetail["audit"] = [
    { who: "Sistema", action: "atividade.criada", ts: daysAgo(14) },
  ];
  const hourEntries: ActivityDetail["hourEntries"] = [];

  if (project) {
    const pm = getUser(project.pmId);
    if (a.status !== "backlog") {
      history.push({
        from: "backlog", to: "ready", by: pm?.name || "PM",
        ts: daysAgo(9), note: "Liberada pelo PM",
      });
      audit.push({
        who: pm?.name || "PM", action: "status.alterado", field: "status",
        old: "backlog", new: "ready", ts: daysAgo(9),
      });
    }
  }
  if (["inprog", "blocked", "wclient", "review", "done"].includes(a.status)) {
    history.push({
      from: "ready", to: "inprog", by: owner?.name || "—",
      ts: daysAgo(6), note: "Consultor iniciou",
    });
    audit.push({
      who: owner?.name || "—", action: "status.alterado", field: "status",
      old: "ready", new: "inprog", ts: daysAgo(6),
    });
    comments.push({
      who: owner?.name || "—",
      txt: "Iniciando a atividade — vou levantar as premissas com o time do cliente antes de começar a configuração.",
      ts: daysAgo(6),
    });
    hourEntries.push({
      date: "2026-08-27", hours: 3, tipo: "Análise",
      desc: "Levantamento inicial + call com key-user", who: owner?.name || "—",
    });
    hourEntries.push({
      date: "2026-08-28", hours: 2.5, tipo: "Configuração",
      desc: "Config parcial", who: owner?.name || "—",
    });
  }
  if (a.status === "blocked") {
    history.push({
      from: "inprog", to: "blocked", by: owner?.name || "—",
      ts: daysAgo(3), note: "API do sistema legado com timeout",
    });
    comments.push({
      who: owner?.name || "—",
      txt: "Bloqueio: API do sistema legado com timeout intermitente. Escalado.",
      ts: daysAgo(3),
    });
  }
  if (a.status === "done") {
    const pm = project && getUser(project.pmId);
    history.push({
      from: "review", to: "done", by: pm?.name || "PM",
      ts: daysAgo(1), note: "Aprovada",
    });
    comments.push({
      who: pm?.name || "PM",
      txt: "Aprovado. Atividades dependentes liberadas.",
      ts: daysAgo(1),
    });
  }

  const attachments: ActivityDetail["attachments"] =
    a.status !== "backlog"
      ? [{
          name: `${a.session}_config_v1.docx`,
          type: "DOCX",
          size: "128 KB",
          who: owner?.name || "—",
          ts: daysAgo(4),
        }]
      : [];

  activityDetails[id] = { subacts, comments, history, audit, hourEntries, attachments };
  return activityDetails[id];
};

/**
 * Move an activity to a new status and cascade the "auto-release dependents"
 * workflow rule. Returns the updated list of activities that changed.
 */
export const moveActivityStatus = (
  id: string,
  newStatus: Activity["status"]
): Activity[] => {
  const a = getActivity(id);
  if (!a) return [];
  const changed: Activity[] = [];
  const oldStatus = a.status;
  a.status = newStatus;
  changed.push(a);

  // Auto-release direct dependents when moving to done.
  if (newStatus === "done" && oldStatus !== "done") {
    activities
      .filter((x) => x.deps.includes(id) && x.status === "backlog")
      .forEach((x) => {
        x.status = "ready";
        changed.push(x);
      });
  }

  const d = getActivityDetail(id);
  if (d) {
    const now = new Date();
    d.history.push({
      from: oldStatus, to: newStatus, by: "Leo Matos", ts: now,
      note: "Movido via UI",
    });
    d.audit.push({
      who: "Leo Matos", action: "status.alterado", field: "status",
      old: oldStatus, new: newStatus, ts: now,
    });
  }
  return changed;
};

/** All activities visible under the given client filter + optional filters */
export const listScopedActivities = (opts: {
  clientId: string;
  filters?: Partial<{
    pm: string; consultor: string; phase: string;
    session: string; status: string; priority: string;
  }>;
  allProjects: { id: string; clientId: string; pmId: string; phase: string }[];
}): Activity[] => {
  const { clientId, filters = {}, allProjects } = opts;
  let projs = clientId === "all" ? allProjects : allProjects.filter((p) => p.clientId === clientId);
  if (filters.pm) projs = projs.filter((p) => p.pmId === filters.pm);
  if (filters.phase) projs = projs.filter((p) => p.phase === filters.phase);
  const pids = projs.map((p) => p.id);
  let acts = activities.filter((a) => pids.includes(a.pid));
  if (filters.consultor) acts = acts.filter((a) => a.ownerId === filters.consultor);
  if (filters.session) acts = acts.filter((a) => a.session === filters.session);
  if (filters.status) acts = acts.filter((a) => a.status === filters.status);
  if (filters.priority) acts = acts.filter((a) => a.prio === filters.priority);
  return acts;
};

// getUser / getProject / getClient are exported by the barrel (@/lib/data)
// via their own modules; no duplicate re-export here to avoid ambiguous
// `export *` collisions.
