import { issues } from "./store";
import type { Issue } from "@/types";

export const listIssues = (): Issue[] => issues;
export const getIssue = (id: string): Issue | undefined => issues.find((i) => i.id === id);
export const listIssuesByProject = (pid: string): Issue[] => issues.filter((i) => i.pid === pid);
export const createIssue = (i: Issue): Issue => { issues.unshift(i); return i; };
export const updateIssue = (id: string, patch: Partial<Issue>): Issue | null => {
  const i = getIssue(id); if (!i) return null;
  Object.assign(i, patch); return i;
};
export const deleteIssue = (id: string): boolean => {
  const idx = issues.findIndex((i) => i.id === id);
  if (idx < 0) return false; issues.splice(idx, 1); return true;
};
export const nextIssueId = (): string => {
  const max = issues.reduce((m, i) => {
    const n = parseInt((i.id.match(/\d+/) || ["0"])[0]) || 0;
    return n > m ? n : m;
  }, 0);
  return "I-" + String(max + 1).padStart(3, "0");
};
