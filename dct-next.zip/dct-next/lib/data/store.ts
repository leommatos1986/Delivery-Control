/**
 * =========================================================================
 * In-memory store — THE ONLY MUTABLE STATE in the app.
 * =========================================================================
 * Every read/write goes through the functions exported from /lib/data/*.
 * When you migrate to Supabase, delete this file and replace the imports
 * inside each domain file (users.ts, projects.ts, etc.) with Supabase queries.
 *
 * IMPORTANT: because Next.js can render the app on both server and client,
 * this module is import-safe on both sides. The mutations only ever run
 * where they were originally triggered — server components are read-only.
 */

import {
  seedUsers,
  seedClients,
  seedProjects,
  seedActivities,
  seedRisks,
  seedIssues,
  seedDecisions,
  seedMilestones,
  seedNotifications,
  seedTemplates,
  seedWorkflowRules,
} from "./seed";

import type {
  User,
  Client,
  Project,
  Activity,
  Risk,
  Issue,
  Decision,
  Milestone,
  Notification,
  Template,
  WorkflowRule,
  ActivityDetail,
} from "@/types";

// Clone arrays so we're not mutating the seed exports (which could be reused
// in tests / server contexts).
export const users: User[] = [...seedUsers];
export const clients: Client[] = [...seedClients];
export const projects: Project[] = [...seedProjects];
export const activities: Activity[] = [...seedActivities];
export const risks: Risk[] = [...seedRisks];
export const issues: Issue[] = [...seedIssues];
export const decisions: Decision[] = [...seedDecisions];
export const milestones: Milestone[] = [...seedMilestones];
export const notifications: Notification[] = [...seedNotifications];
export const templates: Template[] = [...seedTemplates];
export const workflowRules: WorkflowRule[] = [...seedWorkflowRules];

// Rich activity details are lazily generated on first access.
export const activityDetails: Record<string, ActivityDetail> = {};
