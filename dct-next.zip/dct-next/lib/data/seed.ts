/**
 * =========================================================================
 * SEED — initial dataset (was inline in the vanilla artifact)
 * =========================================================================
 * The whole domain state starts here. When you swap to Supabase, keep this
 * file only as a fixture for tests / initial migration.
 */

import type {
  User,
  Client,
  Project,
  Activity,
  Risk,
  Issue,
  Decision,
  Milestone,
  Template,
  WorkflowRule,
  Notification,
} from "@/types";

export const seedUsers: User[] = [
  { id: "u_lm", name: "Leo Matos", role: "Delivery Manager", init: "LM", hue: 210, cap: 40, planned: 32, actual: 29 },
  { id: "u_hr", name: "Helena Reis", role: "PMO / PM", init: "HR", hue: 280, cap: 40, planned: 38, actual: 36 },
  { id: "u_ar", name: "Ana Ribeiro", role: "FI Lead", init: "AR", hue: 340, cap: 40, planned: 42, actual: 47 },
  { id: "u_bc", name: "Bruno Costa", role: "CO Consultant", init: "BC", hue: 180, cap: 40, planned: 38, actual: 34 },
  { id: "u_cs", name: "Camila Souza", role: "MM Consultant", init: "CS", hue: 20, cap: 40, planned: 36, actual: 35 },
  { id: "u_da", name: "Daniel Alves", role: "SD Consultant", init: "DA", hue: 145, cap: 40, planned: 44, actual: 41 },
  { id: "u_ep", name: "Eduardo Prado", role: "PP Consultant", init: "EP", hue: 250, cap: 40, planned: 32, actual: 30 },
  { id: "u_fl", name: "Fernanda Lima", role: "ABAP Developer", init: "FL", hue: 15, cap: 40, planned: 46, actual: 48 },
  { id: "u_gn", name: "Gustavo Nunes", role: "Basis / Technical", init: "GN", hue: 200, cap: 40, planned: 34, actual: 33 },
  { id: "u_im", name: "Igor Martins", role: "Tax / BR Localization", init: "IM", hue: 100, cap: 40, planned: 40, actual: 44 },
  { id: "u_jf", name: "Julia Ferreira", role: "Integration Lead", init: "JF", hue: 320, cap: 40, planned: 38, actual: 35 },
  { id: "u_la", name: "Lucas Andrade", role: "Data Migration", init: "LA", hue: 50, cap: 40, planned: 36, actual: 41 },
  { id: "u_mr", name: "Marina Rocha", role: "Testing Lead", init: "MR", hue: 170, cap: 40, planned: 30, actual: 28 },
  { id: "u_nv", name: "Nicolas Vieira", role: "Change Management", init: "NV", hue: 290, cap: 40, planned: 24, actual: 22 },
  { id: "u_sa", name: "Sofia Almeida", role: "Executive Sponsor", init: "SA", hue: 340, cap: 20, planned: 12, actual: 14 },
  // Client-side stakeholders (external)
  { id: "c_lb", name: "Luiza Bittencourt", role: "CIO — SAPORE", init: "LB", hue: 260, external: true, cap: 0, planned: 0, actual: 0 },
  { id: "c_mg", name: "Marcos Godoi", role: "CFO — SAPORE", init: "MG", hue: 200, external: true, cap: 0, planned: 0, actual: 0 },
  { id: "c_rf", name: "Ricardo Fonseca", role: "Head of Finance — SAPORE", init: "RF", hue: 120, external: true, cap: 0, planned: 0, actual: 0 },
  { id: "c_dt", name: "Rodrigo Vasques", role: "CIO — DATORA", init: "RV", hue: 170, external: true, cap: 0, planned: 0, actual: 0 },
];

export const seedClients: Client[] = [
  { id: "sapore", name: "SAPORE", industry: "Alimentação Corporativa", logo: "SP" },
  { id: "datora", name: "DATORA", industry: "Telecom", logo: "DT" },
  { id: "jbs", name: "JBS", industry: "Proteína Animal", logo: "JB" },
  { id: "braskem", name: "Braskem", industry: "Petroquímica", logo: "BK" },
  { id: "ambev", name: "Ambev", industry: "Bebidas", logo: "AB" },
  { id: "suzano", name: "Suzano", industry: "Papel & Celulose", logo: "SZ" },
];

export const seedProjects: Project[] = [
  {
    id: "p1", clientId: "sapore", name: "Implementação S/4HANA Public Cloud",
    type: "Implementação", phase: "Realize", pmId: "u_hr",
    startDate: "2026-01-15", endDate: "2026-11-30", goLive: "2026-10-05",
    health: "att", progress: 58, plannedHours: 8400, actualHours: 5320,
    activitiesTotal: 412, activitiesDone: 239, activitiesLate: 12,
    risks: 6, issues: 9, milestonesRisk: 1,
    description: "Greenfield S/4HANA Public Cloud — Finance, Controlling, Sales, Procurement, Tax BR",
  },
  {
    id: "p2", clientId: "datora", name: "Implementação S/4HANA Public Cloud",
    type: "Implementação", phase: "Explore", pmId: "u_hr",
    startDate: "2026-03-01", endDate: "2027-02-28", goLive: "2027-01-15",
    health: "risk", progress: 24, plannedHours: 6800, actualHours: 1980,
    activitiesTotal: 328, activitiesDone: 78, activitiesLate: 8,
    risks: 11, issues: 14, milestonesRisk: 2,
    description: "Implementação com forte customização em faturamento e integração com plataforma telecom",
  },
  {
    id: "p3", clientId: "jbs", name: "AMS S/4HANA — Sustentação e Melhorias",
    type: "AMS/Melhoria", phase: "Run", pmId: "u_hr",
    startDate: "2025-06-01", endDate: "2027-05-31", goLive: "—",
    health: "on", progress: 82, plannedHours: 4200, actualHours: 3410,
    activitiesTotal: 186, activitiesDone: 152, activitiesLate: 2,
    risks: 2, issues: 4, milestonesRisk: 0,
    description: "Contrato AMS 24 meses — melhorias contínuas + suporte",
  },
  {
    id: "p4", clientId: "braskem", name: "Roll-out S/4HANA México",
    type: "Implementação", phase: "Deploy", pmId: "u_hr",
    startDate: "2025-11-01", endDate: "2026-09-30", goLive: "2026-09-01",
    health: "on", progress: 88, plannedHours: 5200, actualHours: 4680,
    activitiesTotal: 214, activitiesDone: 189, activitiesLate: 3,
    risks: 3, issues: 5, milestonesRisk: 0,
    description: "Roll-out do template LATAM para operação de Coatzacoalcos",
  },
  {
    id: "p5", clientId: "ambev", name: "Implementação S/4HANA Public Cloud",
    type: "Implementação", phase: "Prepare", pmId: "u_hr",
    startDate: "2026-08-15", endDate: "2027-08-30", goLive: "2027-06-15",
    health: "on", progress: 8, plannedHours: 9200, actualHours: 640,
    activitiesTotal: 34, activitiesDone: 3, activitiesLate: 0,
    risks: 1, issues: 2, milestonesRisk: 0,
    description: "Kick-off recente — Blueprint em preparação",
  },
  {
    id: "p6", clientId: "suzano", name: "AMS + Evolução Fiscal",
    type: "AMS/Melhoria", phase: "Run", pmId: "u_hr",
    startDate: "2025-01-15", endDate: "2027-01-14", goLive: "—",
    health: "att", progress: 74, plannedHours: 3800, actualHours: 2950,
    activitiesTotal: 142, activitiesDone: 106, activitiesLate: 5,
    risks: 3, issues: 6, milestonesRisk: 0,
    description: "Backlog de melhorias fiscais + suporte",
  },
  {
    id: "p7", clientId: "sapore", name: "Melhoria — Automação Contas a Pagar",
    type: "AMS/Melhoria", phase: "Realize", pmId: "u_hr",
    startDate: "2026-07-01", endDate: "2026-10-30", goLive: "2026-10-30",
    health: "on", progress: 41, plannedHours: 640, actualHours: 264,
    activitiesTotal: 38, activitiesDone: 14, activitiesLate: 0,
    risks: 0, issues: 1, milestonesRisk: 0,
    description: "Automação do workflow de aprovação de faturas",
  },
];

export const seedActivities: Activity[] = [
  // SAPORE — Realize
  { id: "a1", pid: "p1", phase: "Realize", session: "Finance", name: "Configurar plano de contas — G/L Accounts", ownerId: "u_ar", status: "inprog", prio: "Alta", due: "2026-09-05", plH: 24, acH: 18, deps: [] },
  { id: "a2", pid: "p1", phase: "Realize", session: "Finance", name: "Definir estrutura organizacional — Company Codes", ownerId: "u_ar", status: "done", prio: "Alta", due: "2026-08-20", plH: 16, acH: 14, deps: [] },
  { id: "a3", pid: "p1", phase: "Realize", session: "Tax", name: "Configuração de impostos ICMS/PIS/COFINS", ownerId: "u_im", status: "inprog", prio: "Alta", due: "2026-09-08", plH: 32, acH: 27, deps: ["a1"] },
  { id: "a4", pid: "p1", phase: "Realize", session: "Sales", name: "Configuração do processo Order-to-Cash", ownerId: "u_da", status: "ready", prio: "Alta", due: "2026-09-15", plH: 40, acH: 0, deps: ["a1"] },
  { id: "a5", pid: "p1", phase: "Realize", session: "Procurement", name: "Configuração do processo Procure-to-Pay", ownerId: "u_cs", status: "inprog", prio: "Média", due: "2026-09-12", plH: 32, acH: 26, deps: [] },
  { id: "a6", pid: "p1", phase: "Realize", session: "Integration", name: "API — Integração com sistema legado (SAP PI/PO)", ownerId: "u_jf", status: "blocked", prio: "Alta", due: "2026-08-30", plH: 48, acH: 22, deps: [] },
  { id: "a7", pid: "p1", phase: "Realize", session: "Data Migration", name: "Migração de dados mestres — Vendors", ownerId: "u_la", status: "wclient", prio: "Alta", due: "2026-09-02", plH: 24, acH: 20, deps: [] },
  { id: "a8", pid: "p1", phase: "Realize", session: "Testing", name: "SIT — Cenário Purchase-to-Pay", ownerId: "u_mr", status: "ready", prio: "Alta", due: "2026-09-20", plH: 32, acH: 0, deps: ["a5"] },
  { id: "a9", pid: "p1", phase: "Realize", session: "Testing", name: "UAT — Cenário Order-to-Cash", ownerId: "u_mr", status: "backlog", prio: "Alta", due: "2026-09-27", plH: 32, acH: 0, deps: ["a4"] },
  { id: "a10", pid: "p1", phase: "Realize", session: "Technical", name: "Configuração de perfis de segurança — Roles S/4", ownerId: "u_gn", status: "inprog", prio: "Média", due: "2026-09-10", plH: 24, acH: 16, deps: [] },
  { id: "a11", pid: "p1", phase: "Realize", session: "Change Management", name: "Plano de comunicação da Wave 1", ownerId: "u_nv", status: "review", prio: "Média", due: "2026-09-05", plH: 16, acH: 14, deps: [] },

  // DATORA — Explore
  { id: "a20", pid: "p2", phase: "Explore", session: "Finance", name: "Blueprint Finance — Chart of Accounts", ownerId: "u_ar", status: "inprog", prio: "Alta", due: "2026-09-01", plH: 40, acH: 44, deps: [] },
  { id: "a21", pid: "p2", phase: "Explore", session: "Sales", name: "Blueprint Sales — Contract Accounting FI-CA", ownerId: "u_da", status: "blocked", prio: "Alta", due: "2026-08-28", plH: 56, acH: 38, deps: [] },
  { id: "a22", pid: "p2", phase: "Explore", session: "Procurement", name: "Blueprint P2P — Direct/Indirect procurement", ownerId: "u_cs", status: "wclient", prio: "Alta", due: "2026-09-04", plH: 32, acH: 22, deps: [] },
  { id: "a23", pid: "p2", phase: "Explore", session: "Integration", name: "Análise de integração — plataforma de billing telecom", ownerId: "u_jf", status: "inprog", prio: "Alta", due: "2026-09-10", plH: 48, acH: 30, deps: [] },
  { id: "a24", pid: "p2", phase: "Explore", session: "Tax", name: "Análise de impostos — telecom (ICMS Comunicação)", ownerId: "u_im", status: "inprog", prio: "Alta", due: "2026-09-08", plH: 32, acH: 34, deps: [] },
  { id: "a25", pid: "p2", phase: "Explore", session: "Master Data", name: "Levantamento de dados mestres — Customers", ownerId: "u_la", status: "ready", prio: "Média", due: "2026-09-14", plH: 24, acH: 0, deps: [] },
  { id: "a26", pid: "p2", phase: "Explore", session: "PMO", name: "Cronograma detalhado — Realize", ownerId: "u_hr", status: "inprog", prio: "Alta", due: "2026-09-03", plH: 16, acH: 12, deps: [] },

  // JBS — AMS
  { id: "a30", pid: "p3", phase: "Deploy", session: "Finance", name: "CR-JBS-0421 — Correção relatório DRE gerencial", ownerId: "u_ar", status: "review", prio: "Média", due: "2026-09-04", plH: 12, acH: 11, deps: [] },
  { id: "a31", pid: "p3", phase: "Realize", session: "Tax", name: "CR-JBS-0435 — Ajuste cálculo IPI", ownerId: "u_im", status: "inprog", prio: "Alta", due: "2026-09-07", plH: 16, acH: 9, deps: [] },
  { id: "a32", pid: "p3", phase: "Realize", session: "ABAP", name: "CR-JBS-0440 — User exit MIGO", ownerId: "u_fl", status: "inprog", prio: "Média", due: "2026-09-09", plH: 24, acH: 20, deps: [] },
  { id: "a33", pid: "p3", phase: "Realize", session: "Integration", name: "CR-JBS-0442 — Ajuste iDoc INVOIC", ownerId: "u_jf", status: "done", prio: "Baixa", due: "2026-08-25", plH: 8, acH: 7, deps: [] },

  // Braskem — Deploy
  { id: "a40", pid: "p4", phase: "Deploy", session: "Cutover", name: "Cutover Plan — Playbook final", ownerId: "u_hr", status: "inprog", prio: "Alta", due: "2026-08-31", plH: 24, acH: 22, deps: [] },
  { id: "a41", pid: "p4", phase: "Deploy", session: "Data Migration", name: "Carga final de dados mestres (Mock 3)", ownerId: "u_la", status: "inprog", prio: "Alta", due: "2026-09-01", plH: 40, acH: 36, deps: [] },
  { id: "a42", pid: "p4", phase: "Deploy", session: "Testing", name: "UAT Round 2 — Sign-off", ownerId: "u_mr", status: "review", prio: "Alta", due: "2026-09-03", plH: 16, acH: 15, deps: [] },
  { id: "a43", pid: "p4", phase: "Deploy", session: "Change Management", name: "Hypercare — Estruturação da equipe", ownerId: "u_nv", status: "ready", prio: "Alta", due: "2026-09-05", plH: 24, acH: 0, deps: [] },
  { id: "a44", pid: "p4", phase: "Deploy", session: "Training", name: "End-user training — Turma final", ownerId: "u_nv", status: "inprog", prio: "Média", due: "2026-09-02", plH: 32, acH: 28, deps: [] },

  // Ambev — Prepare
  { id: "a50", pid: "p5", phase: "Prepare", session: "PMO", name: "Kick-off oficial + Charter assinado", ownerId: "u_hr", status: "done", prio: "Alta", due: "2026-08-25", plH: 16, acH: 14, deps: [] },
  { id: "a51", pid: "p5", phase: "Prepare", session: "PMO", name: "Definição de governança", ownerId: "u_hr", status: "inprog", prio: "Alta", due: "2026-09-08", plH: 24, acH: 12, deps: [] },
  { id: "a52", pid: "p5", phase: "Prepare", session: "Technical", name: "Provisionamento do tenant SAP", ownerId: "u_gn", status: "ready", prio: "Alta", due: "2026-09-12", plH: 16, acH: 0, deps: [] },

  // Suzano
  { id: "a60", pid: "p6", phase: "Realize", session: "Tax", name: "Reforma tributária — Adaptação IBS/CBS (Fase 1)", ownerId: "u_im", status: "inprog", prio: "Alta", due: "2026-09-10", plH: 80, acH: 52, deps: [] },
  { id: "a61", pid: "p6", phase: "Realize", session: "ABAP", name: "Desenvolvimento — Split de nota fiscal", ownerId: "u_fl", status: "inprog", prio: "Alta", due: "2026-09-05", plH: 40, acH: 44, deps: [] },
  { id: "a62", pid: "p6", phase: "Realize", session: "Finance", name: "Ajuste conciliação bancária", ownerId: "u_ar", status: "review", prio: "Baixa", due: "2026-09-01", plH: 12, acH: 10, deps: [] },

  // Sapore — Melhoria AP
  { id: "a70", pid: "p7", phase: "Realize", session: "Finance", name: "Modelagem workflow de aprovação", ownerId: "u_ar", status: "inprog", prio: "Média", due: "2026-09-15", plH: 16, acH: 8, deps: [] },
  { id: "a71", pid: "p7", phase: "Realize", session: "ABAP", name: "Development — Regras de aprovação por alçada", ownerId: "u_fl", status: "ready", prio: "Média", due: "2026-09-25", plH: 32, acH: 0, deps: ["a70"] },
];

export const seedRisks: Risk[] = [
  { id: "R-042", pid: "p2", title: "Escopo de integração com plataforma legada de billing subestimado", prob: "Alta", impact: "Alto", sev: "Critical", ownerId: "u_jf", due: "2026-09-15", status: "Aberto", category: "Integration", activatePhase: "Explore", activityRef: "a23", strategy: "Mitigate", description: "Análise inicial de integração indicou complexidade 3x maior que estimado.", plan: "Escalar para Sponsor + contratar sênior + refazer estimativa", mitigationSteps: ["Contratar sênior Integration", "Refazer discovery técnico", "Ajustar cronograma +3 sem"], contingency: "CR formal se overrun > 20%", earlyWarning: "Blueprint sem fechamento até 15/set", impactAreas: ["schedule", "cost", "quality"], review: "2026-09-08", lastReview: "2026-08-25", ai: true },
  { id: "R-039", pid: "p2", title: "Recurso Fiscal sênior sobrecarregado", prob: "Alta", impact: "Alto", sev: "Critical", ownerId: "u_hr", due: "2026-09-10", status: "Mitigação", category: "Resource", activatePhase: "Explore", activityRef: "a24", strategy: "Mitigate", description: "Igor Martins alocado em 118%.", plan: "Recrutamento + realocação", mitigationSteps: ["Abrir vaga sênior", "Realocar 40% do trabalho", "Contratar temporário"], contingency: "Contratar consultoria externa", earlyWarning: "> 120% por 2 semanas", impactAreas: ["schedule", "quality", "resource"], review: "2026-09-05", lastReview: "2026-08-28", ai: true },
  { id: "R-038", pid: "p1", title: "UAT depende de disponibilidade de key-users", prob: "Média", impact: "Alto", sev: "High", ownerId: "u_hr", due: "2026-09-20", status: "Aberto", category: "Business", activatePhase: "Realize", activityRef: "a9", strategy: "Mitigate", description: "Key-users da SAPORE sem agenda bloqueada.", plan: "Bloqueio de agenda", mitigationSteps: ["Ofício formal", "Steering", "Backup plan"], contingency: "Adiar UAT 1 semana", earlyWarning: "3 dias antes sem agenda", impactAreas: ["schedule", "quality"], review: "2026-09-10", lastReview: "2026-08-30" },
  { id: "R-036", pid: "p1", title: "Dados de fornecedores com qualidade abaixo — 34% inconsistentes", prob: "Média", impact: "Alto", sev: "High", ownerId: "u_la", due: "2026-09-25", status: "Mitigação", category: "Data Quality", activatePhase: "Realize", activityRef: "a7", strategy: "Mitigate", description: "34% CNPJ inválidos ou endereço faltando.", plan: "Sprint de cleansing 2 sem", mitigationSteps: ["Sprint cleansing", "Envolver cliente", "Re-profiling"], contingency: "Wave duplo de migração", earlyWarning: "Se após sprint > 10%", impactAreas: ["schedule", "quality", "cost"], review: "2026-09-12", lastReview: "2026-08-29" },
  { id: "R-031", pid: "p4", title: "Feriado México próximo ao Go-Live", prob: "Baixa", impact: "Alto", sev: "Medium", ownerId: "u_hr", due: "2026-08-31", status: "Aceito", category: "External", activatePhase: "Deploy", activityRef: null, strategy: "Accept", description: "Independência do México 16/set.", plan: "Reforço Hypercare", mitigationSteps: ["+2 consultores Hypercare", "FAQ prévio"], contingency: "—", earlyWarning: "—", impactAreas: ["quality"], review: "2026-09-01", lastReview: "2026-08-15" },
  { id: "R-029", pid: "p6", title: "Reforma tributária BR — regulamentação incompleta", prob: "Alta", impact: "Médio", sev: "High", ownerId: "u_im", due: "2026-10-30", status: "Monitoramento", category: "External", activatePhase: "Realize", activityRef: "a60", strategy: "Mitigate", description: "LC 214/25 aprovada, IN Receita pendente.", plan: "Monitoramento + reserva de horas", mitigationSteps: ["Call semanal sponsor fiscal", "Boletim SAP LATAM"], contingency: "Reduzir escopo IBS Wave 2", earlyWarning: "Publicação IN Receita", impactAreas: ["scope", "schedule", "cost"], review: "2026-09-15", lastReview: "2026-08-20" },
  { id: "R-025", pid: "p2", title: "Cliente sem PMO dedicado — decisões demoradas", prob: "Média", impact: "Médio", sev: "Medium", ownerId: "u_hr", due: "2026-09-30", status: "Aberto", category: "Governance", activatePhase: "Prepare", activityRef: null, strategy: "Mitigate", description: "DATORA sem PMO. Média 8 dias/decisão.", plan: "Solicitar PMO cliente", mitigationSteps: ["Ofício ao Sponsor", "+ Steering", "Registrar pendências >5d"], contingency: "Consultoria assume PMO shadow", earlyWarning: "> 10 dias por 3 semanas", impactAreas: ["schedule", "quality"], review: "2026-09-08", lastReview: "2026-08-22" },
];

export const seedIssues: Issue[] = [
  { id: "I-118", pid: "p1", title: "API do sistema legado retornando timeout — bloqueia teste integrado", sev: "Critical", priority: "P1", ownerId: "u_jf", due: "2026-09-02", status: "Aberto", related: "a6", category: "Integration", activatePhase: "Realize", description: "Timeout intermitente (>30s).", rootCause: "Pool de threads insuficiente + falta circuit breaker.", workaround: "Batches de 50 + sleep 2min.", resolution: "IT cliente amplia pool 48→128 + retry CPI.", impactAreas: ["schedule", "quality"], escalatedTo: "CIO SAPORE", createdAt: "2026-08-29", relatedRiskId: "R-042" },
  { id: "I-115", pid: "p2", title: "Documentação do processo de faturamento telecom incompleta", sev: "High", priority: "P2", ownerId: "u_da", due: "2026-09-05", status: "Aberto", related: "a21", category: "Business Decision", activatePhase: "Explore", description: "30% dos casos documentados.", rootCause: "3 modelos sem padronização.", workaround: "Consultor entrevista key-users.", resolution: "Workshop 8h Sales + Finance + IT.", impactAreas: ["scope", "schedule"], escalatedTo: "Sponsor DATORA", createdAt: "2026-08-27" },
  { id: "I-112", pid: "p1", title: "Divergência sobre alocação de centro de custo", sev: "Medium", priority: "P3", ownerId: "u_ar", due: "2026-09-08", status: "Análise", related: "a1", category: "Configuration", activatePhase: "Realize", description: "Controller pede por UN, Contabilidade por CR.", rootCause: "Reorg interna não refletida na doc.", workaround: "—", resolution: "Modelo híbrido em Steering.", impactAreas: ["scope"], escalatedTo: "PMO", createdAt: "2026-08-30" },
  { id: "I-108", pid: "p6", title: "Erro no cálculo de IBS em cenário de bonificação", sev: "High", priority: "P2", ownerId: "u_im", due: "2026-09-07", status: "Aberto", related: "a60", category: "Defect", activatePhase: "Realize", description: "IBS calcula 26,5% em NF bonificação (deveria ser 0%).", rootCause: "Natureza 5.9xx não mapeada.", workaround: "Manual override no lançamento.", resolution: "Ajustar tabela de condições.", impactAreas: ["quality"], escalatedTo: "—", createdAt: "2026-08-31" },
  { id: "I-104", pid: "p2", title: "Data-set com encoding UTF-8 quebrado", sev: "Medium", priority: "P3", ownerId: "u_la", due: "2026-09-04", status: "Mitigação", related: "", category: "Data Quality", activatePhase: "Realize", description: "8.4k registros com acentos corrompidos.", rootCause: "Extração em Latin-1.", workaround: "—", resolution: "Re-extrair em UTF-8 + sanitização.", impactAreas: ["quality", "schedule"], escalatedTo: "—", createdAt: "2026-08-28" },
  { id: "I-101", pid: "p4", title: "UAT México — 3 cenários com resultado inconclusivo", sev: "High", priority: "P2", ownerId: "u_mr", due: "2026-09-01", status: "Retest", related: "a42", category: "Defect", activatePhase: "Deploy", description: "DIOT + ISR + carta porte com divergências.", rootCause: "Localização MX incompleta + OSS Note pendente.", workaround: "—", resolution: "Aplicar OSS Note 3298541.", impactAreas: ["quality", "schedule"], escalatedTo: "—", createdAt: "2026-08-30" },
  { id: "I-099", pid: "p3", title: "Job noturno falhando 1x/semana", sev: "Low", priority: "P4", ownerId: "u_gn", due: "2026-09-15", status: "Análise", related: "", category: "Environment", activatePhase: "Run", description: "Z_MRP_RUN timeout às terças 3am.", rootCause: "Provável falta de índice.", workaround: "Restart manual Basis.", resolution: "Criar índice.", impactAreas: ["quality"], escalatedTo: "—", createdAt: "2026-08-15" },
];

export const seedDecisions: Decision[] = [
  { id: "D-018", pid: "p1", date: "2026-08-20", title: "Adotar SAP Best Practices para P2P sem customizações no primeiro release", ownerId: "u_hr", context: "12 fit-gaps inviáveis no cronograma", outcome: "Standard + fit-gaps para wave 2", category: "Scope", activatePhase: "Explore", status: "Approved", approvedBy: "c_lb", dueImpact: "—", reversibility: "Reversible", optionsEvaluated: ["Adotar standard + wave 2 (escolhida)", "12 fit-gaps agora (+8 sem)", "3 devs adicionais (+R$180k)"], impactAreas: { scope: "-12 fit-gaps wave 1", schedule: "Mantém cronograma", cost: "Neutro", quality: "Standard SAP" }, linkedActivities: ["a4", "a5"], linkedRisks: [], linkedIssues: [] },
  { id: "D-017", pid: "p2", date: "2026-08-18", title: "Adiar fase Realize em 3 semanas", ownerId: "u_hr", context: "Complexidade FI-CA maior que estimada", outcome: "Aprovado — Go-Live mantido via compressão de UAT", category: "Schedule", activatePhase: "Explore", status: "Approved", approvedBy: "c_lb", dueImpact: "2027-01-15", reversibility: "Irreversible", optionsEvaluated: ["Adiar Realize +3 sem (escolhida)", "Adiar Go-Live +3 sem", "Reduzir escopo FI-CA"], impactAreas: { scope: "Mantido", schedule: "Realize +3sem", cost: "+R$80k", quality: "Risco médio UAT curto" }, linkedActivities: ["a20", "a21"], linkedRisks: ["R-042"], linkedIssues: [] },
  { id: "D-016", pid: "p6", date: "2026-08-12", title: "Priorizar reforma tributária IBS/CBS", ownerId: "u_hr", context: "Prazo legal + risco fiscal", outcome: "Backlog de melhorias congelado até out/2026", category: "Business", activatePhase: "Realize", status: "Approved", approvedBy: "u_sa", dueImpact: "2026-10-30", reversibility: "Reversible", optionsEvaluated: ["Priorizar reforma (escolhida)", "Manter ambas (+R$120k)", "Terceirizar melhorias"], impactAreas: { scope: "Melhorias postergadas 3m", schedule: "—", cost: "Neutro", quality: "Foco 100% compliance" }, linkedActivities: ["a60", "a61"], linkedRisks: ["R-029"], linkedIssues: ["I-108"] },
  { id: "D-015", pid: "p4", date: "2026-08-05", title: "Manter Go-Live México em 01/set", ownerId: "u_hr", context: "Alinhamento fechamento contábil Q3", outcome: "Reforçar Hypercare +2 consultores", category: "Governance", activatePhase: "Deploy", status: "Approved", approvedBy: "c_lb", dueImpact: "2026-09-01", reversibility: "Irreversible", optionsEvaluated: ["Manter + reforçar Hypercare (escolhida)", "Adiar 15d", "Adiar 30d"], impactAreas: { scope: "Mantido", schedule: "Mantido", cost: "+R$45k", quality: "Mitigado" }, linkedActivities: ["a40", "a41", "a42", "a43"], linkedRisks: ["R-031"], linkedIssues: [] },
];

export const seedMilestones: Milestone[] = [
  { id: "m1", pid: "p1", name: "Explore Complete", planned: "2026-06-15", actual: "2026-06-20", status: "done" },
  { id: "m2", pid: "p1", name: "SIT Start", planned: "2026-09-01", actual: "2026-09-01", status: "inprog" },
  { id: "m3", pid: "p1", name: "UAT Start", planned: "2026-09-20", actual: "", status: "planned" },
  { id: "m4", pid: "p1", name: "Cutover", planned: "2026-10-01", actual: "", status: "planned" },
  { id: "m5", pid: "p1", name: "Business Go-Live", planned: "2026-10-05", actual: "", status: "risk" },
  { id: "m6", pid: "p1", name: "Hypercare Complete", planned: "2026-11-30", actual: "", status: "planned" },
  { id: "m10", pid: "p2", name: "Blueprint Sign-off", planned: "2026-08-30", actual: "", status: "risk" },
  { id: "m11", pid: "p2", name: "Realize Start", planned: "2026-09-15", actual: "", status: "risk" },
  { id: "m20", pid: "p4", name: "UAT Complete", planned: "2026-08-30", actual: "2026-08-29", status: "done" },
  { id: "m21", pid: "p4", name: "Business Go-Live", planned: "2026-09-01", actual: "", status: "inprog" },
];

export const seedNotifications: Notification[] = [
  { id: "n1", ts: "há 12 min", level: "crit", text: "<b>SAPORE</b> — Atividade I-118 (API timeout) bloqueia UAT" },
  { id: "n2", ts: "há 34 min", level: "warn", text: "<b>DATORA</b> — Blueprint Finance consumiu <b>110%</b> das horas" },
  { id: "n3", ts: "há 1 h", level: "warn", text: "<b>Milestone em risco</b> — DATORA · Blueprint Sign-off" },
  { id: "n4", ts: "há 2 h", level: "info", text: "Nova atividade atribuída a Daniel Alves — O2C SAPORE" },
  { id: "n5", ts: "há 3 h", level: "good", text: "<b>Braskem</b> — UAT Round 2 concluído" },
  { id: "n6", ts: "há 5 h", level: "crit", text: "<b>Ana Ribeiro</b> — Capacidade em <b>118%</b>" },
  { id: "n7", ts: "ontem", level: "warn", text: "<b>SAPORE</b> — 12 atividades atrasadas > 3 dias" },
];

export const seedTemplates: Template[] = [
  {
    id: "tpl_s4pc", name: "SAP S/4HANA Public Cloud",
    desc: "Implementação greenfield · fases Prepare→Explore→Realize→Deploy→Run",
    type: "Implementação", durationMonths: 12, totalHours: 8400,
    phases: [
      { name: "Prepare", pctDuration: 0.10, sessions: [
        { name: "PMO", acts: [{ name: "Kick-off + Charter", h: 16, prio: "Alta" }, { name: "Governança", h: 24, prio: "Alta" }] },
        { name: "Technical", acts: [{ name: "Provisionamento tenant", h: 16, prio: "Alta" }] },
      ] },
      { name: "Explore", pctDuration: 0.25, sessions: [
        { name: "Finance", acts: [{ name: "Blueprint FI — CoA", h: 40, prio: "Alta" }] },
        { name: "Sales", acts: [{ name: "Blueprint O2C", h: 48, prio: "Alta" }] },
        { name: "Procurement", acts: [{ name: "Blueprint P2P", h: 40, prio: "Alta" }] },
      ] },
      { name: "Realize", pctDuration: 0.40, sessions: [
        { name: "Finance", acts: [{ name: "Config G/L", h: 24, prio: "Alta" }] },
        { name: "Testing", acts: [{ name: "SIT P2P", h: 32, prio: "Alta" }, { name: "UAT O2C", h: 32, prio: "Alta" }] },
      ] },
      { name: "Deploy", pctDuration: 0.15, sessions: [
        { name: "Cutover", acts: [{ name: "Cutover Plan", h: 24, prio: "Alta" }] },
      ] },
      { name: "Run", pctDuration: 0.10, sessions: [
        { name: "Change Management", acts: [{ name: "Hypercare", h: 80, prio: "Alta" }] },
      ] },
    ],
  },
  {
    id: "tpl_ams", name: "AMS / Sustentação",
    desc: "Contrato AMS · fluxo Backlog→Análise→Desenho→Dev→Teste→Deploy",
    type: "AMS/Melhoria", durationMonths: 24, totalHours: 4800,
    phases: [
      { name: "Backlog", pctDuration: 0.05, sessions: [{ name: "PMO", acts: [{ name: "Triagem", h: 16, prio: "Média" }] }] },
      { name: "Análise", pctDuration: 0.15, sessions: [{ name: "Functional", acts: [{ name: "Análise funcional", h: 80, prio: "Média" }] }] },
      { name: "Desenho", pctDuration: 0.15, sessions: [{ name: "Functional", acts: [{ name: "Design", h: 60, prio: "Média" }] }] },
      { name: "Desenvolvimento", pctDuration: 0.30, sessions: [{ name: "ABAP", acts: [{ name: "Dev CRs", h: 120, prio: "Média" }] }] },
      { name: "Teste", pctDuration: 0.15, sessions: [{ name: "Testing", acts: [{ name: "Testes", h: 40, prio: "Média" }] }] },
      { name: "Homologação", pctDuration: 0.10, sessions: [{ name: "Testing", acts: [{ name: "Homologação", h: 32, prio: "Média" }] }] },
      { name: "Deploy", pctDuration: 0.05, sessions: [{ name: "Basis", acts: [{ name: "Deploy", h: 16, prio: "Alta" }] }] },
      { name: "Concluído", pctDuration: 0.05, sessions: [{ name: "PMO", acts: [{ name: "Fechamento", h: 8, prio: "Baixa" }] }] },
    ],
  },
];

export const seedWorkflowRules: WorkflowRule[] = [
  { id: "R01", name: "Auto-liberação de dependentes", cond: "Atividade concluída", then: "Liberar dependentes (backlog→ready) + notificar", enabled: true, category: "Kanban" },
  { id: "R02", name: "Alerta de atraso", cond: "due < hoje AND status ≠ done", then: "Overdue + notificar owner + PM", enabled: true, category: "Alertas" },
  { id: "R03", name: "Effort Risk", cond: "horas > 80% AND progresso < 60%", then: "Alerta owner + PM", enabled: true, category: "Horas" },
  { id: "R04", name: "Orçamento estourado", cond: "horas > 100% do plano", then: "Notificar PM + Delivery", enabled: true, category: "Horas" },
  { id: "R05", name: "Projeto em risco por issues", cond: "> 5 Issues High/Critical", then: "Health = At Risk", enabled: true, category: "Governança" },
  { id: "R06", name: "Milestone próximo em risco", cond: "milestone < 5 dias, não iniciado", then: "Alerta PM + Delivery", enabled: true, category: "Cronograma" },
  { id: "R07", name: "Sobrecarga de recurso", cond: "consultor > 100% cap por 2 sem", then: "Alerta Overload", enabled: true, category: "Recursos" },
  { id: "R08", name: "Atividade sem responsável", cond: "> 24h sem owner", then: "Alerta Unassigned", enabled: true, category: "Kanban" },
  { id: "R09", name: "Cliente segurando decisão", cond: "Waiting Client > 3 dias", then: "Escalar PM cliente", enabled: true, category: "Governança" },
  { id: "R10", name: "Forecast > orçamento", cond: "forecast_custo > budget", then: "Alerta financeiro", enabled: false, category: "Financeiro" },
];
