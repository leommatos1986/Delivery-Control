import { clients } from "./store";
import type { Client } from "@/types";

export const listClients = (): Client[] => clients;
export const getClient = (id: string): Client | undefined =>
  clients.find((c) => c.id === id);
export const createClient = (c: Client): Client => {
  clients.push(c);
  return c;
};
export const updateClient = (id: string, patch: Partial<Client>): Client | null => {
  const c = getClient(id);
  if (!c) return null;
  Object.assign(c, patch);
  return c;
};
export const deleteClient = (id: string): boolean => {
  const idx = clients.findIndex((c) => c.id === id);
  if (idx < 0) return false;
  clients.splice(idx, 1);
  return true;
};
