/**
 * Barrel — the single import surface for the app.
 * Components should ONLY import from "@/lib/data".
 */
export * from "./users";
export * from "./clients";
export * from "./projects";
export * from "./activities";
export * from "./risks";
export * from "./issues";
export * from "./decisions";
export * from "./milestones";
export * from "./notifications";
export * from "./templates";
export * from "./workflows";
