/**
 * Governance Top-10 builder — derives an ordered list of items that need
 * management attention from the current state.
 */

import {
  listActivities,
  listRisks,
  listIssues,
  listMilestones,
  internalUsers,
  safeUtilPct,
  getUser,
  getProject,
  getClient,
  listProjects,
} from "@/lib/data";
import { daysUntil } from "@/lib/formatters";

export interface GovItem {
  sev: "critical" | "high" | "medium";
  sevLbl: string;
  client: string;
  title: string;
  desc: string;
  sort: number;
  kind: "risk" | "issue" | "overdue" | "blocked" | "milestone" | "overload";
  refId?: string;
}

export function buildGovernanceList(clientFilter: string): GovItem[] {
  const items: GovItem[] = [];
  const projects = clientFilter === "all"
    ? listProjects()
    : listProjects().filter((p) => p.clientId === clientFilter);
  const projIds = projects.map((p) => p.id);

  // Overdue activities
  listActivities()
    .filter((a) => projIds.includes(a.pid))
    .forEach((a) => {
      const d = daysUntil(a.due);
      if (d != null && d < 0 && a.status !== "done") {
        const p = getProject(a.pid);
        const cl = p && getClient(p.clientId);
        const owner = getUser(a.ownerId);
        items.push({
          kind: "overdue",
          refId: a.id,
          sev: "critical",
          sevLbl: "Critical",
          client: cl?.name || "—",
          title: `Atividade atrasada há ${-d} dia${-d > 1 ? "s" : ""}`,
          desc: `${a.name} · Resp: ${owner?.name || "—"}`,
          sort: 100 + -d,
        });
      }
    });

  // Critical risks
  listRisks()
    .filter((r) => projIds.includes(r.pid) && r.sev === "Critical")
    .forEach((r) => {
      const p = getProject(r.pid);
      const cl = p && getClient(p.clientId);
      const owner = getUser(r.ownerId);
      items.push({
        kind: "risk", refId: r.id,
        sev: "critical", sevLbl: "Critical",
        client: cl?.name || "—",
        title: r.title,
        desc: `Risco ${r.id} · Owner: ${owner?.name || "—"}`,
        sort: 90,
      });
    });

  // Blocked activities
  listActivities()
    .filter((a) => projIds.includes(a.pid) && a.status === "blocked")
    .forEach((a) => {
      const p = getProject(a.pid);
      const cl = p && getClient(p.clientId);
      const owner = getUser(a.ownerId);
      items.push({
        kind: "blocked", refId: a.id,
        sev: "high", sevLbl: "High",
        client: cl?.name || "—",
        title: "Atividade bloqueada — " + a.name,
        desc: "Owner: " + (owner?.name || "—"),
        sort: 80,
      });
    });

  // High/critical issues
  listIssues()
    .filter((i) => projIds.includes(i.pid) && (i.sev === "Critical" || i.sev === "High"))
    .forEach((is) => {
      const p = getProject(is.pid);
      const cl = p && getClient(p.clientId);
      items.push({
        kind: "issue", refId: is.id,
        sev: is.sev.toLowerCase() as "critical" | "high",
        sevLbl: is.sev,
        client: cl?.name || "—",
        title: is.title,
        desc: `Issue ${is.id} · ${is.status}`,
        sort: is.sev === "Critical" ? 95 : 75,
      });
    });

  // Overloaded resources (internal only)
  internalUsers()
    .filter((u) => safeUtilPct(u) > 1.1)
    .forEach((u) => {
      items.push({
        kind: "overload", refId: u.id,
        sev: "high", sevLbl: "High",
        client: "—",
        title: `${u.name} — capacidade em ${Math.round(safeUtilPct(u) * 100)}%`,
        desc: `${u.role} · ${u.actual}h / ${u.cap}h`,
        sort: 70,
      });
    });

  // Milestones at risk
  listMilestones()
    .filter((m) => projIds.includes(m.pid) && m.status === "risk")
    .forEach((m) => {
      const p = getProject(m.pid);
      const cl = p && getClient(p.clientId);
      items.push({
        kind: "milestone", refId: m.id,
        sev: "critical", sevLbl: "Critical",
        client: cl?.name || "—",
        title: `Milestone em risco — ${m.name}`,
        desc: "Planejado: " + m.planned,
        sort: 92,
      });
    });

  return items.sort((a, b) => b.sort - a.sort);
}
