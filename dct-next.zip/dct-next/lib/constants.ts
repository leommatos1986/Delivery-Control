import type { KanbanColumn } from "@/types";

export const PHASES_IMPL = [
  "Prepare",
  "Explore",
  "Realize",
  "Deploy",
  "Run",
] as const;

export const PHASES_AMS = [
  "Backlog",
  "Análise",
  "Desenho",
  "Desenvolvimento",
  "Teste",
  "Homologação",
  "Deploy",
  "Concluído",
] as const;

export const ACTIVATE_PHASES = [
  "Discover",
  "Prepare",
  "Explore",
  "Realize",
  "Deploy",
  "Run",
] as const;

export const SESSIONS = [
  "Finance",
  "Controlling",
  "Sales",
  "Procurement",
  "Manufacturing",
  "Tax",
  "Master Data",
  "Integration",
  "Data Migration",
  "Testing",
  "Cutover",
  "Change Management",
  "Training",
  "PMO",
  "Technical",
  "ABAP",
];

export const KANBAN_COLS: KanbanColumn[] = [
  { id: "backlog", label: "Backlog", color: "#8B95A3" },
  { id: "ready", label: "Ready", color: "#4A6FBF" },
  { id: "inprog", label: "In Progress", color: "#1F3A5F" },
  { id: "blocked", label: "Blocked", color: "#B93838" },
  { id: "wclient", label: "Waiting Client", color: "#6E48A8" },
  { id: "review", label: "Review", color: "#B37A1A" },
  { id: "done", label: "Done", color: "#2E7D57" },
];

export const IMPACT_LABEL: Record<string, string> = {
  scope: "Escopo",
  schedule: "Cronograma",
  cost: "Custo",
  quality: "Qualidade",
  resource: "Recursos",
};

export const RISK_CATEGORIES = [
  "Scope",
  "Schedule",
  "Cost",
  "Quality",
  "Resource",
  "Technical",
  "Integration",
  "External",
  "Change Mgmt",
  "Business",
];
export const RISK_STRATEGIES = ["Avoid", "Transfer", "Mitigate", "Accept"];
export const RISK_STATUSES = [
  "Identified",
  "Analyzing",
  "Mitigation",
  "Monitoring",
  "Realized",
  "Closed",
];
export const ISSUE_CATEGORIES = [
  "Defect",
  "Configuration",
  "Data Quality",
  "Integration",
  "Process Gap",
  "Business Decision",
  "Environment",
  "Performance",
  "Access/Security",
];
export const ISSUE_STATUSES = [
  "New",
  "Analyzing",
  "In Progress",
  "Waiting Client",
  "Resolved",
  "Verified",
  "Closed",
];
export const DECISION_CATEGORIES = [
  "Scope",
  "Design",
  "Architecture",
  "Process",
  "Business",
  "Technical",
  "Contractual",
  "Governance",
];
export const DECISION_STATUSES = [
  "Draft",
  "Pending",
  "Approved",
  "Rejected",
  "Superseded",
];

// Blended hourly rates by role (BRL/h) — used by saving calculator
export const DEFAULT_HOURLY_RATE = 260;
export const HR_RATES: Record<string, number> = {
  "Delivery Manager": 420,
  "PMO / PM": 340,
  "PMO Lead": 340,
  "Solution Architect": 520,
  "FI Lead": 310,
  "FI Consultant": 260,
  "CO Consultant": 240,
  "MM Consultant": 240,
  "SD Consultant": 240,
  "PP Consultant": 240,
  "ABAP Developer": 220,
  "Basis / Cloud": 240,
  "Basis / Technical": 240,
  "Tax / BR Localization": 320,
  "Tax / BR Loc.": 320,
  "Integration Lead": 300,
  "Data Migration": 240,
  "Testing Lead": 220,
  "Change Management": 240,
  "Change Manager": 240,
  "Executive Sponsor": 600,
};
