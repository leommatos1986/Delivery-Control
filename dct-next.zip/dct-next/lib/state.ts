/**
 * =========================================================================
 * UI-only client state (drawer, modal, filters, theme).
 * =========================================================================
 * This is not domain data — it's ephemeral UI state that has to be shared
 * across sibling client components (e.g. Sidebar filter change → Kanban
 * re-render). We use Zustand for its tiny footprint and SSR-friendliness.
 */

"use client";

import { create } from "zustand";
import type { FilterState } from "@/types";

interface UIState {
  clientFilter: string;
  setClientFilter: (id: string) => void;

  filters: FilterState;
  setFilter: <K extends keyof FilterState>(key: K, value: FilterState[K]) => void;
  clearFilters: () => void;

  drawerActivityId: string | null;
  drawerTab: string;
  openDrawer: (id: string, tab?: string) => void;
  closeDrawer: () => void;
  setDrawerTab: (tab: string) => void;

  modalContent: React.ReactNode | null;
  openModal: (content: React.ReactNode) => void;
  closeModal: () => void;
}

const emptyFilters: FilterState = {
  pm: null, consultor: null, phase: null, session: null,
  status: null, priority: null, period: null,
};

export const useUI = create<UIState>((set) => ({
  clientFilter: "all",
  setClientFilter: (id) => set({ clientFilter: id }),

  filters: emptyFilters,
  setFilter: (key, value) =>
    set((s) => ({ filters: { ...s.filters, [key]: value } })),
  clearFilters: () => set({ clientFilter: "all", filters: emptyFilters }),

  drawerActivityId: null,
  drawerTab: "overview",
  openDrawer: (id, tab = "overview") =>
    set({ drawerActivityId: id, drawerTab: tab }),
  closeDrawer: () => set({ drawerActivityId: null }),
  setDrawerTab: (tab) => set({ drawerTab: tab }),

  modalContent: null,
  openModal: (content) => set({ modalContent: content }),
  closeModal: () => set({ modalContent: null }),
}));
