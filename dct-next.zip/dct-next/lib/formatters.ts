/** Formatting helpers — pure functions, safe to use in server or client */

export const fmtN = (n: number): string =>
  new Intl.NumberFormat("pt-BR").format(Math.round(n));

export const fmtH = (n: number): string => fmtN(n) + "h";

export const fmtDate = (s?: string | null): string => {
  if (!s || s === "—") return "—";
  const d = new Date(s + "T00:00:00");
  return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });
};

/** Days between `s` and "today" (2026-09-02 for the demo).
 *  Positive = future, negative = past, 0 = today. */
export const daysUntil = (s?: string | null): number | null => {
  if (!s) return null;
  const d = new Date(s + "T00:00:00");
  const now = new Date("2026-09-02T00:00:00");
  return Math.round((d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
};

export const pct = (a: number, b: number): number =>
  b === 0 ? 0 : Math.round((a / b) * 100);

export const fmtCurrencyShort = (v: number): string => {
  const abs = Math.abs(v);
  if (abs >= 1e6) return "R$ " + (v / 1e6).toFixed(2).replace(".", ",") + "M";
  if (abs >= 1e3) return "R$ " + (v / 1e3).toFixed(0) + "k";
  return "R$ " + Math.round(v);
};

export const fmtBytes = (b: number): string => {
  if (b < 1024) return b + " B";
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " KB";
  return (b / 1024 / 1024).toFixed(1) + " MB";
};

export const avatarBg = (hue: number): string =>
  `hsl(${hue},48%,42%)`;

export const healthLabel = (h: string): string =>
  ({ on: "On Track", att: "Attention", risk: "At Risk", crit: "Critical" }[h] || h);

export const healthClass = (h: string): string =>
  ({ on: "health-on", att: "health-att", risk: "health-risk", crit: "health-crit" }[h] || "");

export const priorityBadgeClass = (p: string): string => {
  if (p === "Alta") return "badge-crit";
  if (p === "Média") return "badge-warn";
  return "badge-outline";
};

/** Simple XSS-safe escaper — usually not needed with React, kept for the very
 *  few `dangerouslySetInnerHTML` spots (chart tooltips, etc). */
export const esc = (s?: string | number | null): string =>
  s == null
    ? ""
    : String(s).replace(/[&<>"']/g, (c) =>
        ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!)
      );

export const weekLabel = (): string => {
  const d = new Date("2026-09-02T00:00:00");
  const start = new Date(d);
  start.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return `${String(start.getDate()).padStart(2, "0")}/${String(
    start.getMonth() + 1
  ).padStart(2, "0")}`;
};
