"use client";

import type { GovItem } from "@/lib/governance";
import { Badge } from "@/components/ui/Badge";

export function GovernanceTop10({ items }: { items: GovItem[] }) {
  return (
    <div>
      {items.slice(0, 10).map((g, i) => (
        <div
          key={i}
          className="grid grid-cols-[32px_1fr_auto_auto] gap-3 py-2.5 px-3.5 border-b items-center"
          style={{ borderBottomColor: "var(--border)" }}
        >
          <div
            className="font-mono text-[11px] text-ink-3 text-center rounded font-semibold py-1"
            style={{ background: "var(--panel-3)" }}
          >
            {String(i + 1).padStart(2, "0")}
          </div>
          <div className="text-[12.5px] text-ink font-medium leading-snug">
            <span className="text-ink-3 font-mono text-[11px] mr-1.5">{g.client}</span>
            {g.title}
            <small className="block font-normal text-ink-2 text-[11.5px] mt-0.5">
              {g.desc}
            </small>
          </div>
          <Badge
            variant={
              g.sev === "critical" ? "crit" : g.sev === "high" ? "warn" : "info"
            }
          >
            {g.sevLbl}
          </Badge>
          <button className="btn btn-sm btn-ghost">→</button>
        </div>
      ))}
    </div>
  );
}
