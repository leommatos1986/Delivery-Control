"use client";

import { useMemo } from "react";
import {
  listProjects,
  listActivities,
  internalUsers,
  safeUtilPct,
  getClient,
} from "@/lib/data";
import { useUI } from "@/lib/state";
import { daysUntil, fmtN, weekLabel } from "@/lib/formatters";
import { buildGovernanceList } from "@/lib/governance";
import { KpiTile } from "@/components/ui/KpiTile";
import { Card, CardHeader, CardBody } from "@/components/ui/Card";
import { Icon } from "@/components/ui/Icon";
import { PortfolioTable } from "./PortfolioTable";
import { GovernanceTop10 } from "./GovernanceTop10";

export function HomeView() {
  const clientFilter = useUI((s) => s.clientFilter);

  const {
    projs, total, onTrack, att, risk, openAct, lateAct,
    plH, acH, util, topGov, clientLabel,
  } = useMemo(() => {
    const all = listProjects();
    const projs = clientFilter === "all" ? all : all.filter((p) => p.clientId === clientFilter);
    const total = projs.length;
    const onTrack = projs.filter((p) => p.health === "on").length;
    const att = projs.filter((p) => p.health === "att").length;
    const risk = projs.filter((p) => p.health === "risk" || p.health === "crit").length;
    const projIds = projs.map((p) => p.id);
    const acts = listActivities().filter((a) => projIds.includes(a.pid));
    const openAct = acts.filter((a) => a.status !== "done").length;
    const lateAct = acts.filter((a) => {
      const d = daysUntil(a.due);
      return d != null && d < 0 && a.status !== "done";
    }).length;
    const plH = projs.reduce((s, p) => s + p.plannedHours, 0);
    const acH = projs.reduce((s, p) => s + p.actualHours, 0);
    const internos = internalUsers();
    const util = internos.length
      ? Math.round(internos.reduce((s, u) => s + safeUtilPct(u) * 100, 0) / internos.length)
      : 0;
    const topGov = buildGovernanceList(clientFilter);
    const clientLabel = clientFilter === "all"
      ? "todos os clientes"
      : getClient(clientFilter)?.name || "—";
    return { projs, total, onTrack, att, risk, openAct, lateAct, plH, acH, util, topGov, clientLabel };
  }, [clientFilter]);

  return (
    <>
      <div className="mb-5">
        <div className="flex justify-between items-start gap-6">
          <div>
            <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">
              Delivery Overview
            </h1>
            <p className="text-ink-2 text-[13.5px] m-0">
              Portfólio consolidado — {clientLabel} · semana {weekLabel()}
            </p>
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <button className="btn btn-primary">
              <Icon name="download" />
              Exportar Excel
            </button>
          </div>
        </div>
      </div>

      {/* KPI ROW */}
      <div className="grid grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-3 mb-5">
        <KpiTile
          label="Projetos ativos"
          value={total}
          accent="accent"
          foot={<span>{onTrack} on track · {att} attention · {risk} risk</span>}
        />
        <KpiTile
          label="Atividades atrasadas"
          value={lateAct}
          accent="warn"
          foot={<span>vs semana anterior</span>}
        />
        <KpiTile
          label="Projetos em risco"
          value={risk}
          accent="crit"
          foot={
            <span>
              {projs.filter((p) => p.health === "risk").map((p) => getClient(p.clientId)?.name).join(" · ") || "—"}
            </span>
          }
        />
        <KpiTile
          label="Horas planejadas"
          value={fmtN(plH)}
          smaller
          foot={
            <span className="mono">
              {fmtN(acH)}h realizadas · {plH ? Math.round((acH / plH) * 100) : 0}%
            </span>
          }
        />
        <KpiTile
          label="Utilização do time"
          value={<>{util}<span style={{ fontSize: 16, color: "var(--ink-3)" }}>%</span></>}
          accent={util > 95 ? "crit" : util > 85 ? "warn" : "good"}
          foot={<span>{util > 95 ? "sobrecarga" : util > 85 ? "saudável" : "folga"}</span>}
        />
      </div>

      {/* PORTFOLIO + TOP-10 */}
      <div className="grid grid-cols-1 xl:grid-cols-[3fr_2fr] gap-4 mb-5">
        <Card>
          <CardHeader title="Portfólio ativo" action={<button className="btn btn-sm btn-ghost">Ver todos →</button>} />
          <PortfolioTable projects={projs} />
        </Card>
        <Card>
          <CardHeader title="Top 10 · Atenção da gestão" action={<button className="btn btn-sm btn-ghost">Governança →</button>} />
          <GovernanceTop10 items={topGov} />
        </Card>
      </div>

      {/* Feed placeholder — full charts to be ported in next round */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <Card>
          <CardHeader title="Feed recente" sub="últimas 24h" />
          <CardBody>
            <div className="text-[12.5px] text-ink-2 leading-relaxed">
              Feed / timeline / charts serão migrados na próxima rodada.
              Toda a lógica já está no /lib/data e pronta para consumo.
            </div>
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Charts (burn-down / plan vs actual)" sub="a migrar" />
          <CardBody>
            <div className="text-[12.5px] text-ink-2">
              Ver <code>components/dashboard/charts/</code> na próxima entrega.
            </div>
          </CardBody>
        </Card>
      </div>
    </>
  );
}
