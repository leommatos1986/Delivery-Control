"use client";

import Link from "next/link";
import type { Project } from "@/types";
import { getUser, getClient } from "@/lib/data";
import { Avatar } from "@/components/ui/Avatar";
import { HealthChip } from "@/components/ui/HealthChip";
import { PBar } from "@/components/ui/PBar";
import { fmtN } from "@/lib/formatters";

export function PortfolioTable({ projects }: { projects: Project[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="tbl">
        <thead>
          <tr>
            <th>Projeto</th>
            <th>Fase</th>
            <th>PM</th>
            <th>Progresso</th>
            <th>Horas</th>
            <th className="center">Health</th>
          </tr>
        </thead>
        <tbody>
          {projects.map((p) => {
            const cl = getClient(p.clientId);
            const pm = getUser(p.pmId);
            return (
              <tr key={p.id} style={{ cursor: "pointer" }}>
                <td className="cell-primary">
                  <div>
                    <span className="mono txt-mut" style={{ fontSize: 11 }}>
                      {cl?.name}
                    </span>
                  </div>
                  <Link href={`/projects/${p.id}`}>{p.name}</Link>
                </td>
                <td>{p.phase}</td>
                <td><Avatar user={pm} size={22} /></td>
                <td><PBar value={p.progress} /></td>
                <td className="cell-mono">
                  {fmtN(p.actualHours)}
                  <span className="txt-mut">/{fmtN(p.plannedHours)}</span>
                </td>
                <td className="center">
                  <HealthChip health={p.health} />
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
