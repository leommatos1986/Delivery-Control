import clsx from "clsx";
import type { ReactNode } from "react";

type Accent = "default" | "accent" | "good" | "warn" | "crit";

export function KpiTile({
  label,
  value,
  foot,
  accent = "default",
  smaller = false,
}: {
  label: string;
  value: ReactNode;
  foot?: ReactNode;
  accent?: Accent;
  smaller?: boolean;
}) {
  const accentCls = {
    default: "",
    accent: "kpi-accent",
    good: "kpi-good",
    warn: "kpi-warn",
    crit: "kpi-crit",
  }[accent];
  return (
    <div className={clsx("kpi", accentCls)}>
      <span className="lbl">{label}</span>
      <span className={clsx("val", smaller && "smaller")}>{value}</span>
      {foot ? <div className="foot">{foot}</div> : null}
    </div>
  );
}
