import { avatarBg } from "@/lib/formatters";
import type { User } from "@/types";

export function Avatar({ user, size = 28 }: { user: User | undefined; size?: number }) {
  if (!user) return null;
  return (
    <div
      className="avatar"
      style={{
        width: size,
        height: size,
        fontSize: Math.max(9, size * 0.36),
        background: avatarBg(user.hue),
      }}
      title={user.name}
    >
      {user.init}
    </div>
  );
}
