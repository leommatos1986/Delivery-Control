import clsx from "clsx";

type Tone = "default" | "good" | "warn" | "crit";

export function PBar({
  value,
  tone = "default",
  showLabel = true,
}: {
  value: number;
  tone?: Tone;
  showLabel?: boolean;
}) {
  const v = Math.min(100, Math.max(0, value));
  const toneCls = { default: "", good: "good", warn: "warn", crit: "crit" }[tone];
  return (
    <div className="pbar">
      <div className="pbar-track">
        <div className={clsx("pbar-fill", toneCls)} style={{ width: `${v}%` }} />
      </div>
      {showLabel && <span className="pbar-lbl">{value}%</span>}
    </div>
  );
}
