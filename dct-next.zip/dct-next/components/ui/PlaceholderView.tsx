import { Card, CardHeader, CardBody } from "@/components/ui/Card";

/**
 * Placeholder view used by pages whose full functionality is being ported
 * from the vanilla HTML artifact into Next.js components. Data layer is
 * ready; UI is next.
 */
export function PlaceholderView({
  title,
  desc,
  bullets,
}: {
  title: string;
  desc: string;
  bullets: string[];
}) {
  return (
    <>
      <div className="mb-5">
        <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">
          {title}
        </h1>
        <p className="text-ink-2 text-[13.5px] m-0">{desc}</p>
      </div>
      <Card>
        <CardHeader title="Em migração — próxima rodada" sub="a UI está sendo portada do protótipo vanilla" />
        <CardBody>
          <p className="text-[13px] text-ink-2 leading-relaxed m-0 mb-3">
            A camada de dados (<code>/lib/data</code>) já está pronta e populada.
            Esta tela existe apenas para manter a navegação sem 404 e será
            reimplementada em componentes React na próxima entrega.
          </p>
          <div className="text-[12.5px] text-ink-2">
            <b className="text-ink">O que virá aqui:</b>
            <ul className="mt-2 mb-0 pl-5 list-disc">
              {bullets.map((b, i) => (
                <li key={i} className="mb-1">{b}</li>
              ))}
            </ul>
          </div>
        </CardBody>
      </Card>
    </>
  );
}
