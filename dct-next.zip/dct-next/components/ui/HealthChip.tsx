import { healthClass, healthLabel } from "@/lib/formatters";
import type { Health } from "@/types";

export function HealthChip({ health }: { health: Health }) {
  return (
    <span className={`health ${healthClass(health)}`}>
      <span className="dot-in" />
      {healthLabel(health)}
    </span>
  );
}
