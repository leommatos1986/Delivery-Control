import clsx from "clsx";
import type { ReactNode } from "react";

type Variant = "default" | "good" | "warn" | "crit" | "info" | "purple" | "outline";

export function Badge({
  variant = "default",
  children,
  className,
}: {
  variant?: Variant;
  children: ReactNode;
  className?: string;
}) {
  const cls = {
    default: "",
    good: "badge-good",
    warn: "badge-warn",
    crit: "badge-crit",
    info: "badge-info",
    purple: "badge-purple",
    outline: "badge-outline",
  }[variant];
  return <span className={clsx("badge", cls, className)}>{children}</span>;
}
