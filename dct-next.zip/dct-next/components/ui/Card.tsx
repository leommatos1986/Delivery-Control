import clsx from "clsx";
import type { ReactNode } from "react";

export function Card({
  children,
  className,
  onClick,
}: {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  return (
    <div className={clsx("card", className)} onClick={onClick} style={onClick ? { cursor: "pointer" } : undefined}>
      {children}
    </div>
  );
}

export function CardHeader({
  title,
  sub,
  action,
}: {
  title: ReactNode;
  sub?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="card-hd">
      <h3>
        {title}
        {sub ? <span className="sub" style={{ marginLeft: 6 }}>{sub}</span> : null}
      </h3>
      {action}
    </div>
  );
}

export function CardBody({
  children,
  flush = false,
  className,
}: {
  children: ReactNode;
  flush?: boolean;
  className?: string;
}) {
  return (
    <div className={clsx("card-bd", flush && "flush", className)}>{children}</div>
  );
}
