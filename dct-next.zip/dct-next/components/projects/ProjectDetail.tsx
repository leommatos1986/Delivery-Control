"use client";

/**
 * Project detail — SAP Activate flavored dashboard for a single project.
 * Tabs: Overview · Atividades · Milestones · Riscos · Issues · Decisões · Horas
 */

import Link from "next/link";
import { useState, useMemo } from "react";
import {
  getProject,
  getClient,
  getUser,
  listActivitiesByProject,
  listMilestonesByProject,
  listRisksByProject,
  listIssuesByProject,
  listDecisionsByProject,
} from "@/lib/data";
import { useUI } from "@/lib/state";
import { fmtDate, fmtH, daysUntil, priorityBadgeClass } from "@/lib/formatters";
import { KANBAN_COLS } from "@/lib/constants";
import { Card, CardHeader, CardBody } from "@/components/ui/Card";
import { HealthChip } from "@/components/ui/HealthChip";
import { PBar } from "@/components/ui/PBar";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { KpiTile } from "@/components/ui/KpiTile";

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "acts", label: "Atividades" },
  { id: "milestones", label: "Milestones" },
  { id: "risks", label: "Riscos" },
  { id: "issues", label: "Issues" },
  { id: "decisions", label: "Decisões" },
];

export function ProjectDetail({ projectId }: { projectId: string }) {
  const [tab, setTab] = useState("overview");
  const project = getProject(projectId);

  if (!project) {
    return (
      <div className="text-center py-16">
        <h2 className="text-[18px] text-ink mb-2">Projeto não encontrado</h2>
        <Link href="/projects" className="text-accent">← Voltar para projetos</Link>
      </div>
    );
  }

  const client = getClient(project.clientId);
  const pm = getUser(project.pmId);
  const acts = listActivitiesByProject(projectId);
  const miles = listMilestonesByProject(projectId);
  const risks = listRisksByProject(projectId);
  const issues = listIssuesByProject(projectId);
  const decisions = listDecisionsByProject(projectId);

  const late = acts.filter((a) => {
    const d = daysUntil(a.due);
    return d != null && d < 0 && a.status !== "done";
  }).length;
  const done = acts.filter((a) => a.status === "done").length;
  const efficiency = project.actualHours
    ? Math.round((project.plannedHours / project.actualHours) * 100)
    : 100;

  return (
    <>
      {/* Breadcrumb + title */}
      <div className="mb-4">
        <div className="text-[11.5px] text-ink-3 mb-1">
          <Link href="/projects" className="hover:text-ink">Projetos</Link> · {client?.name}
        </div>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="m-0 text-[22px] font-semibold tracking-tight text-ink">
              {project.name}
            </h1>
            <div className="flex items-center gap-3 mt-2">
              <HealthChip health={project.health} />
              <Badge variant="info">{project.type}</Badge>
              <Badge variant="purple">{project.phase}</Badge>
              <span className="text-[12px] text-ink-2">
                Go-Live: <b className="mono">{fmtDate(project.goLive)}</b>
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Avatar user={pm} size={30} />
            <div className="text-[11.5px] leading-tight">
              <div className="text-ink-3">PM</div>
              <div className="text-ink font-medium">{pm?.name || "—"}</div>
            </div>
          </div>
        </div>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-5">
        <KpiTile label="Progresso" value={`${project.progress}%`} accent="accent" foot={<span>{done}/{acts.length} atividades</span>} />
        <KpiTile label="Atividades atrasadas" value={late} accent={late > 0 ? "crit" : "good"} />
        <KpiTile label="Horas realizadas" value={fmtH(project.actualHours)} smaller foot={<span className="mono">/{fmtH(project.plannedHours)}</span>} />
        <KpiTile label="Eficiência" value={`${efficiency}%`} accent={efficiency < 90 ? "warn" : "good"} />
        <KpiTile label="Riscos + Issues" value={risks.length + issues.length} accent={risks.length + issues.length > 5 ? "warn" : "default"} foot={<span>{risks.length} riscos · {issues.length} issues</span>} />
      </div>

      {/* Tabs */}
      <div
        className="flex gap-1 border-b mb-4 overflow-x-auto scroll-thin"
        style={{ borderBottomColor: "var(--border)" }}
      >
        {TABS.map((t) => {
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`text-[13px] px-3 py-2 border-b-2 whitespace-nowrap transition-colors ${
                active ? "text-accent font-medium" : "text-ink-2 hover:text-ink border-transparent"
              }`}
              style={active ? { borderBottomColor: "var(--accent)" } : { borderBottomColor: "transparent" }}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Bodies */}
      {tab === "overview" && (
        <Card>
          <CardHeader title="Descrição" />
          <CardBody>
            <p className="text-[13px] text-ink-2 leading-relaxed m-0">
              {project.description || "Sem descrição registrada. Adicione um contexto executivo aqui para o cliente."}
            </p>
            <div className="mt-4 grid grid-cols-2 lg:grid-cols-4 gap-2 text-[12.5px]">
              <KV k="Início" v={fmtDate(project.startDate)} />
              <KV k="Fim" v={fmtDate(project.endDate)} />
              <KV k="Go-Live" v={fmtDate(project.goLive)} />
              <KV k="Milestones em risco" v={String(project.milestonesRisk)} />
            </div>
          </CardBody>
        </Card>
      )}
      {tab === "acts" && <ActsPanel acts={acts} />}
      {tab === "milestones" && <MilestonesPanel miles={useMemoized(miles, project.goLive)} />}
      {tab === "risks" && <RisksPanel risks={risks} />}
      {tab === "issues" && <IssuesPanel issues={issues} />}
      {tab === "decisions" && <DecisionsPanel decisions={decisions} />}
    </>
  );
}

// ------- Helpers --------------------------------------------------------
function useMemoized<T>(arr: T[], _dep: unknown) { return arr; }

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div className="p-2 rounded" style={{ background: "var(--panel-3)" }}>
      <div className="text-[10.5px] text-ink-3 uppercase tracking-wider">{k}</div>
      <div className="text-[12.5px] text-ink mt-0.5 mono">{v}</div>
    </div>
  );
}

function ActsPanel({ acts }: { acts: ReturnType<typeof listActivitiesByProject> }) {
  const openDrawer = useUI((s) => s.openDrawer);
  return (
    <Card>
      <CardHeader title={`Atividades (${acts.length})`} />
      <div className="overflow-x-auto">
        <table className="tbl">
          <thead>
            <tr>
              <th>Atividade</th>
              <th>Fase / Sessão</th>
              <th>Responsável</th>
              <th>Status</th>
              <th>Prazo</th>
              <th>Horas</th>
              <th>Prio</th>
            </tr>
          </thead>
          <tbody>
            {acts.map((a) => {
              const owner = getUser(a.ownerId);
              const kc = KANBAN_COLS.find((k) => k.id === a.status);
              const d = daysUntil(a.due);
              return (
                <tr key={a.id} style={{ cursor: "pointer" }} onClick={() => openDrawer(a.id)}>
                  <td className="cell-primary">
                    <span className="mono txt-mut" style={{ fontSize: 11 }}>{a.id}</span>
                    <div>{a.name}</div>
                  </td>
                  <td className="text-[11.5px] text-ink-2">{a.phase}<br /><span className="text-ink-3">{a.session}</span></td>
                  <td><Avatar user={owner} size={22} /></td>
                  <td>
                    <Badge variant={a.status === "blocked" ? "crit" : a.status === "done" ? "good" : "info"}>
                      <span className="inline-block w-1.5 h-1.5 rounded-full mr-1.5" style={{ background: kc?.color }} />
                      {kc?.label}
                    </Badge>
                  </td>
                  <td className={`mono text-[11.5px] ${d != null && d < 0 ? "text-crit" : ""}`}>
                    {fmtDate(a.due)}{d != null && d < 0 && ` · ${-d}d`}
                  </td>
                  <td className="cell-mono">{fmtH(a.acH)}<span className="txt-mut">/{fmtH(a.plH)}</span></td>
                  <td><Badge className={priorityBadgeClass(a.prio)}>{a.prio}</Badge></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function MilestonesPanel({ miles }: { miles: ReturnType<typeof listMilestonesByProject> }) {
  return (
    <Card>
      <CardHeader title={`Milestones (${miles.length})`} />
      <div className="overflow-x-auto">
        <table className="tbl">
          <thead>
            <tr><th>Marco</th><th>Planejado</th><th>Real</th><th>Status</th></tr>
          </thead>
          <tbody>
            {miles.map((m) => (
              <tr key={m.id}>
                <td className="cell-primary">{m.name}</td>
                <td className="mono text-[11.5px]">{fmtDate(m.planned)}</td>
                <td className="mono text-[11.5px]">{m.actual === "—" ? "—" : fmtDate(m.actual)}</td>
                <td>
                  <Badge variant={m.status === "done" ? "good" : m.status === "risk" ? "crit" : "info"}>
                    {m.status}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function RisksPanel({ risks }: { risks: ReturnType<typeof listRisksByProject> }) {
  return (
    <Card>
      <CardHeader title={`Risk Register (${risks.length})`} />
      <div className="overflow-x-auto">
        <table className="tbl">
          <thead>
            <tr><th>ID</th><th>Risco</th><th>Sev</th><th>Owner</th><th>Status</th></tr>
          </thead>
          <tbody>
            {risks.map((r) => {
              const owner = getUser(r.ownerId);
              return (
                <tr key={r.id}>
                  <td className="mono text-[11.5px]">{r.id}</td>
                  <td className="cell-primary">{r.title}</td>
                  <td>
                    <Badge variant={r.sev === "Critical" ? "crit" : r.sev === "High" ? "warn" : "info"}>{r.sev}</Badge>
                  </td>
                  <td>{owner?.name || "—"}</td>
                  <td>{r.status}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function IssuesPanel({ issues }: { issues: ReturnType<typeof listIssuesByProject> }) {
  return (
    <Card>
      <CardHeader title={`Issues (${issues.length})`} />
      <div className="overflow-x-auto">
        <table className="tbl">
          <thead>
            <tr><th>ID</th><th>Issue</th><th>Sev</th><th>Owner</th><th>Status</th></tr>
          </thead>
          <tbody>
            {issues.map((i) => {
              const owner = getUser(i.ownerId);
              return (
                <tr key={i.id}>
                  <td className="mono text-[11.5px]">{i.id}</td>
                  <td className="cell-primary">{i.title}</td>
                  <td>
                    <Badge variant={i.sev === "Critical" ? "crit" : i.sev === "High" ? "warn" : "info"}>{i.sev}</Badge>
                  </td>
                  <td>{owner?.name || "—"}</td>
                  <td>{i.status}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function DecisionsPanel({ decisions }: { decisions: ReturnType<typeof listDecisionsByProject> }) {
  return (
    <Card>
      <CardHeader title={`Decision Log (${decisions.length})`} />
      <div className="overflow-x-auto">
        <table className="tbl">
          <thead>
            <tr><th>ID</th><th>Data</th><th>Decisão</th><th>Categoria</th><th>Status</th></tr>
          </thead>
          <tbody>
            {decisions.map((d) => (
              <tr key={d.id}>
                <td className="mono text-[11.5px]">{d.id}</td>
                <td className="mono text-[11.5px]">{fmtDate(d.date)}</td>
                <td className="cell-primary">{d.title}</td>
                <td>{d.category || "—"}</td>
                <td>
                  <Badge variant={d.status === "Approved" ? "good" : d.status === "Rejected" ? "crit" : "info"}>
                    {d.status || "—"}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
