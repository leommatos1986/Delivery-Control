"use client";

/**
 * Right-side slide-in drawer showing rich detail of a single Activity.
 * Tabs: Overview · Subacts · History · Comments · Hours · Attachments · Deps · Audit
 *
 * Data comes entirely from /lib/data — swap that layer for Supabase later
 * and this component keeps working unchanged.
 */

import { useState, useMemo } from "react";
import {
  getActivity,
  getActivityDetail,
  getProject,
  getClient,
  getUser,
  listActivities,
  moveActivityStatus,
} from "@/lib/data";
import { useUI } from "@/lib/state";
import {
  fmtDate,
  fmtH,
  daysUntil,
  healthLabel,
  priorityBadgeClass,
} from "@/lib/formatters";
import { KANBAN_COLS } from "@/lib/constants";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { PBar } from "@/components/ui/PBar";
import { Icon } from "@/components/ui/Icon";
import type { ActivityStatus } from "@/types";

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "subacts", label: "Subatividades" },
  { id: "history", label: "Histórico" },
  { id: "comments", label: "Comentários" },
  { id: "hours", label: "Horas" },
  { id: "attachments", label: "Anexos" },
  { id: "deps", label: "Dependências" },
  { id: "audit", label: "Auditoria" },
];

export function ActivityDrawer({ activityId }: { activityId: string }) {
  const closeDrawer = useUI((s) => s.closeDrawer);
  const drawerTab = useUI((s) => s.drawerTab);
  const setDrawerTab = useUI((s) => s.setDrawerTab);
  const [, force] = useState(0);

  const activity = getActivity(activityId);
  const detail = useMemo(() => getActivityDetail(activityId), [activityId]);
  if (!activity || !detail) return null;

  const project = getProject(activity.pid);
  const client = project && getClient(project.clientId);
  const owner = getUser(activity.ownerId);
  const due = daysUntil(activity.due);
  const dueClass =
    due != null && due < 0 ? "text-crit" : due != null && due <= 2 ? "text-warn" : "text-ink-2";
  const consumed = activity.plH ? Math.round((activity.acH / activity.plH) * 100) : 0;
  const kanbanCol = KANBAN_COLS.find((k) => k.id === activity.status);

  const handleStatusChange = (s: ActivityStatus) => {
    moveActivityStatus(activityId, s);
    force((n) => n + 1);
  };

  return (
    <aside
      className="fixed top-0 right-0 h-full z-[90] bg-panel border-l shadow-2xl flex flex-col"
      style={{
        width: "min(760px, 96vw)",
        borderLeftColor: "var(--border)",
      }}
    >
      {/* Header */}
      <div
        className="flex items-start justify-between gap-3 p-4 border-b flex-shrink-0"
        style={{ borderBottomColor: "var(--border)" }}
      >
        <div className="flex-1 min-w-0">
          <div className="text-[11px] text-ink-3 mono mb-1">
            {client?.name} · {project?.name} · {activity.phase} / {activity.session}
          </div>
          <h2 className="text-[16px] font-semibold text-ink m-0 leading-snug">
            {activity.name}
          </h2>
          <div className="flex flex-wrap items-center gap-2 mt-2">
            <Badge variant={activity.status === "blocked" ? "crit" : "info"}>
              <span
                className="inline-block w-1.5 h-1.5 rounded-full mr-1.5"
                style={{ background: kanbanCol?.color || "#8B95A3" }}
              />
              {kanbanCol?.label || activity.status}
            </Badge>
            <Badge className={priorityBadgeClass(activity.prio)}>
              {activity.prio}
            </Badge>
            <span className={`text-[11.5px] mono ${dueClass}`}>
              {fmtDate(activity.due)}
              {due != null && due < 0 && ` · ${-due}d atraso`}
              {due != null && due >= 0 && due <= 2 && ` · em ${due}d`}
            </span>
          </div>
        </div>
        <button className="btn btn-sm btn-ghost" onClick={closeDrawer} title="Fechar">
          <Icon name="close" />
        </button>
      </div>

      {/* Quick KPIs */}
      <div className="grid grid-cols-3 gap-2 p-3 border-b" style={{ borderBottomColor: "var(--border)" }}>
        <div className="p-2 rounded" style={{ background: "var(--panel-3)" }}>
          <div className="text-[10.5px] text-ink-3 uppercase tracking-wider">Responsável</div>
          <div className="flex items-center gap-2 mt-1">
            <Avatar user={owner} size={20} />
            <span className="text-[12.5px] text-ink">{owner?.name || "—"}</span>
          </div>
        </div>
        <div className="p-2 rounded" style={{ background: "var(--panel-3)" }}>
          <div className="text-[10.5px] text-ink-3 uppercase tracking-wider">Horas</div>
          <div className="text-[13px] mono text-ink mt-1">
            {fmtH(activity.acH)}
            <span className="text-ink-3"> / {fmtH(activity.plH)}</span>
          </div>
          <PBar value={consumed} />
        </div>
        <div className="p-2 rounded" style={{ background: "var(--panel-3)" }}>
          <div className="text-[10.5px] text-ink-3 uppercase tracking-wider">Alterar status</div>
          <select
            value={activity.status}
            onChange={(e) => handleStatusChange(e.target.value as ActivityStatus)}
            className="w-full mt-1 text-[12px] px-2 py-1 rounded border bg-panel"
            style={{ borderColor: "var(--border)", color: "var(--ink)" }}
          >
            {KANBAN_COLS.map((k) => (
              <option key={k.id} value={k.id}>{k.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Tabs */}
      <div
        className="flex gap-1 px-3 border-b overflow-x-auto scroll-thin flex-shrink-0"
        style={{ borderBottomColor: "var(--border)" }}
      >
        {TABS.map((t) => {
          const active = drawerTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setDrawerTab(t.id)}
              className={`text-[12.5px] px-3 py-2 border-b-2 whitespace-nowrap transition-colors ${
                active
                  ? "text-accent font-medium"
                  : "text-ink-2 hover:text-ink border-transparent"
              }`}
              style={active ? { borderBottomColor: "var(--accent)" } : { borderBottomColor: "transparent" }}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto scroll-thin p-4">
        {drawerTab === "overview" && (
          <OverviewTab
            activity={activity}
            project={project}
            healthLbl={project ? healthLabel(project.health) : "—"}
          />
        )}
        {drawerTab === "subacts" && <SubactsTab detail={detail} />}
        {drawerTab === "history" && <HistoryTab detail={detail} />}
        {drawerTab === "comments" && <CommentsTab detail={detail} />}
        {drawerTab === "hours" && <HoursTab detail={detail} />}
        {drawerTab === "attachments" && <AttachmentsTab detail={detail} />}
        {drawerTab === "deps" && <DepsTab activityId={activityId} />}
        {drawerTab === "audit" && <AuditTab detail={detail} />}
      </div>
    </aside>
  );
}

// ---------- Tab bodies -----------------------------------------------------
type ActivityLike = ReturnType<typeof getActivity>;
type DetailLike = NonNullable<ReturnType<typeof getActivityDetail>>;

function OverviewTab({
  activity, project, healthLbl,
}: {
  activity: NonNullable<ActivityLike>;
  project: ReturnType<typeof getProject>;
  healthLbl: string;
}) {
  return (
    <div className="space-y-4">
      <Section title="Sobre a atividade">
        <p className="text-[13px] text-ink-2 leading-relaxed">
          Atividade da fase <b>{activity.phase}</b>, sessão <b>{activity.session}</b>,
          integrando o projeto <b>{project?.name}</b>.
        </p>
      </Section>
      <Section title="Projeto">
        <div className="grid grid-cols-2 gap-2 text-[12.5px]">
          <KV k="Nome" v={project?.name} />
          <KV k="Fase" v={project?.phase} />
          <KV k="Health" v={healthLbl} />
          <KV k="Go-Live" v={fmtDate(project?.goLive)} />
        </div>
      </Section>
      <Section title="Dependências diretas">
        <div className="text-[12.5px] text-ink-2">
          {activity.deps.length === 0
            ? "Nenhuma dependência declarada."
            : `${activity.deps.length} atividade(s) predecessora(s).`}
        </div>
      </Section>
    </div>
  );
}

function SubactsTab({ detail }: { detail: DetailLike }) {
  if (detail.subacts.length === 0)
    return <Empty text="Nenhuma subatividade cadastrada." />;
  return (
    <ul className="space-y-1.5">
      {detail.subacts.map((s) => (
        <li key={s.id} className="flex items-start gap-2 text-[13px]">
          <input type="checkbox" defaultChecked={s.done} className="mt-0.5" />
          <div className="flex-1">
            <div className={s.done ? "line-through text-ink-3" : "text-ink"}>{s.text}</div>
            <div className="text-[11px] text-ink-3">{s.who}</div>
          </div>
        </li>
      ))}
    </ul>
  );
}

function HistoryTab({ detail }: { detail: DetailLike }) {
  if (detail.history.length === 0) return <Empty text="Sem histórico." />;
  return (
    <ol className="space-y-3">
      {detail.history.map((h, i) => (
        <li key={i} className="border-l-2 pl-3" style={{ borderLeftColor: "var(--accent-soft-border)" }}>
          <div className="text-[12.5px] text-ink">
            <span className="mono text-[11px] text-ink-3">{h.from || "—"}</span>
            <span className="mx-1 text-ink-3">→</span>
            <span className="mono text-[11px] text-ink">{h.to}</span>
          </div>
          <div className="text-[12px] text-ink-2 mt-0.5">{h.note}</div>
          <div className="text-[11px] text-ink-3 mt-0.5">
            {h.by} · {h.ts.toLocaleString("pt-BR")}
          </div>
        </li>
      ))}
    </ol>
  );
}

function CommentsTab({ detail }: { detail: DetailLike }) {
  if (detail.comments.length === 0) return <Empty text="Nenhum comentário." />;
  return (
    <div className="space-y-3">
      {detail.comments.map((c, i) => (
        <div key={i} className="rounded p-3" style={{ background: "var(--panel-3)" }}>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[12.5px] font-medium text-ink">{c.who}</span>
            <span className="text-[11px] text-ink-3">{c.ts.toLocaleString("pt-BR")}</span>
          </div>
          <p className="m-0 text-[12.5px] text-ink-2 leading-relaxed">{c.txt}</p>
        </div>
      ))}
    </div>
  );
}

function HoursTab({ detail }: { detail: DetailLike }) {
  if (detail.hourEntries.length === 0) return <Empty text="Nenhum apontamento." />;
  const total = detail.hourEntries.reduce((s, e) => s + e.hours, 0);
  return (
    <div>
      <div className="text-[12px] text-ink-2 mb-3">
        Total apontado: <b className="mono text-ink">{fmtH(total)}</b>
      </div>
      <table className="tbl">
        <thead>
          <tr>
            <th>Data</th>
            <th>Consultor</th>
            <th>Tipo</th>
            <th className="right">Horas</th>
          </tr>
        </thead>
        <tbody>
          {detail.hourEntries.map((e, i) => (
            <tr key={i}>
              <td className="mono">{e.date}</td>
              <td>{e.who}</td>
              <td>{e.tipo}</td>
              <td className="right mono">{e.hours.toFixed(1)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AttachmentsTab({ detail }: { detail: DetailLike }) {
  if (detail.attachments.length === 0) return <Empty text="Nenhum anexo." />;
  return (
    <ul className="space-y-2">
      {detail.attachments.map((a, i) => (
        <li key={i} className="flex items-center justify-between p-2 rounded" style={{ background: "var(--panel-3)" }}>
          <div>
            <div className="text-[13px] text-ink">{a.name}</div>
            <div className="text-[11px] text-ink-3">
              {a.type} · {a.size} · {a.who}
            </div>
          </div>
          <button className="btn btn-sm btn-ghost">Baixar</button>
        </li>
      ))}
    </ul>
  );
}

function DepsTab({ activityId }: { activityId: string }) {
  const activity = getActivity(activityId);
  if (!activity) return null;
  const predecessores = activity.deps
    .map((id) => listActivities().find((a) => a.id === id))
    .filter(Boolean);
  const sucessores = listActivities().filter((a) => a.deps.includes(activityId));
  return (
    <div className="space-y-4">
      <Section title={`Predecessoras (${predecessores.length})`}>
        {predecessores.length === 0 ? (
          <Empty text="Nenhuma predecessora." />
        ) : (
          <ul className="space-y-1.5">
            {predecessores.map((a) => (
              <li key={a!.id} className="text-[12.5px] text-ink-2">
                <span className="mono text-[11px] text-ink-3 mr-2">{a!.id}</span>
                {a!.name}
              </li>
            ))}
          </ul>
        )}
      </Section>
      <Section title={`Sucessoras (${sucessores.length})`}>
        {sucessores.length === 0 ? (
          <Empty text="Nenhuma sucessora." />
        ) : (
          <ul className="space-y-1.5">
            {sucessores.map((a) => (
              <li key={a.id} className="text-[12.5px] text-ink-2">
                <span className="mono text-[11px] text-ink-3 mr-2">{a.id}</span>
                {a.name}
              </li>
            ))}
          </ul>
        )}
      </Section>
    </div>
  );
}

function AuditTab({ detail }: { detail: DetailLike }) {
  if (detail.audit.length === 0) return <Empty text="Sem trilha de auditoria." />;
  return (
    <table className="tbl">
      <thead>
        <tr>
          <th>Quando</th>
          <th>Quem</th>
          <th>Ação</th>
          <th>Campo</th>
          <th>De → Para</th>
        </tr>
      </thead>
      <tbody>
        {detail.audit.map((a, i) => (
          <tr key={i}>
            <td className="mono text-[11px]">{a.ts.toLocaleString("pt-BR")}</td>
            <td>{a.who}</td>
            <td className="mono text-[11px]">{a.action}</td>
            <td className="mono text-[11px]">{a.field || "—"}</td>
            <td className="mono text-[11px]">
              {a.old != null ? String(a.old) : "—"} → {a.new != null ? String(a.new) : "—"}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// ---------- Micro helpers --------------------------------------------------
function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-[11px] uppercase tracking-wider text-ink-3 font-semibold m-0 mb-2">
        {title}
      </h3>
      {children}
    </div>
  );
}
function KV({ k, v }: { k: string; v?: string | null }) {
  return (
    <div className="p-2 rounded" style={{ background: "var(--panel-3)" }}>
      <div className="text-[10.5px] text-ink-3 uppercase tracking-wider">{k}</div>
      <div className="text-[12.5px] text-ink mt-0.5">{v || "—"}</div>
    </div>
  );
}
function Empty({ text }: { text: string }) {
  return <div className="text-[12.5px] text-ink-3 italic py-6 text-center">{text}</div>;
}
