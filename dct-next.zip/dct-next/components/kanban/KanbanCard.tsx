"use client";

import { getUser, getProject, getClient } from "@/lib/data";
import { useUI } from "@/lib/state";
import { fmtDate, fmtH, daysUntil, priorityBadgeClass } from "@/lib/formatters";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { PBar } from "@/components/ui/PBar";
import type { Activity } from "@/types";

export function KanbanCard({ activity }: { activity: Activity }) {
  const openDrawer = useUI((s) => s.openDrawer);
  const owner = getUser(activity.ownerId);
  const project = getProject(activity.pid);
  const client = project && getClient(project.clientId);
  const due = daysUntil(activity.due);
  const consumed = activity.plH ? Math.round((activity.acH / activity.plH) * 100) : 0;

  const dueTone =
    due != null && due < 0 ? "text-crit" : due != null && due <= 2 ? "text-warn" : "text-ink-2";

  return (
    <div
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData("text/plain", activity.id);
        e.dataTransfer.effectAllowed = "move";
      }}
      onClick={() => openDrawer(activity.id)}
      className="rounded p-3 mb-2 cursor-pointer border bg-panel hover:shadow-sm transition-shadow"
      style={{ borderColor: "var(--border)" }}
    >
      <div className="text-[10.5px] mono text-ink-3 mb-1">
        {client?.name} · {activity.session}
      </div>
      <div className="text-[12.5px] font-medium text-ink leading-snug mb-2">
        {activity.name}
      </div>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <Avatar user={owner} size={20} />
          <span className="text-[11px] text-ink-2">{owner?.init || "—"}</span>
        </div>
        <Badge className={priorityBadgeClass(activity.prio)}>{activity.prio}</Badge>
      </div>
      <div className="flex items-center justify-between text-[10.5px] mono">
        <span className={dueTone}>
          {fmtDate(activity.due)}
          {due != null && due < 0 && ` · ${-due}d`}
        </span>
        <span className="text-ink-3">
          {fmtH(activity.acH)}/{fmtH(activity.plH)}
        </span>
      </div>
      <div className="mt-1.5">
        <PBar value={consumed} showLabel={false} tone={consumed > 100 ? "crit" : consumed > 80 ? "warn" : "default"} />
      </div>
    </div>
  );
}
