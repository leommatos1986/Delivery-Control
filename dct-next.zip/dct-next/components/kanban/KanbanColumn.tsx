"use client";

import { useState } from "react";
import { moveActivityStatus } from "@/lib/data";
import { KanbanCard } from "./KanbanCard";
import type { Activity, KanbanColumn as ColDef } from "@/types";

export function KanbanColumn({
  col,
  items,
  onChange,
}: {
  col: ColDef;
  items: Activity[];
  onChange: () => void;
}) {
  const [hover, setHover] = useState(false);

  return (
    <div
      className="rounded-md flex flex-col min-w-[280px] w-[280px] flex-shrink-0"
      style={{ background: hover ? "var(--panel-3)" : "var(--panel-2)" }}
      onDragOver={(e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
        if (!hover) setHover(true);
      }}
      onDragLeave={() => setHover(false)}
      onDrop={(e) => {
        e.preventDefault();
        const id = e.dataTransfer.getData("text/plain");
        setHover(false);
        if (id) {
          moveActivityStatus(id, col.id);
          onChange();
        }
      }}
    >
      <div
        className="flex items-center justify-between px-3 py-2 border-b sticky top-0 z-[1]"
        style={{
          borderBottomColor: "var(--border)",
          background: "var(--panel-2)",
        }}
      >
        <div className="flex items-center gap-2">
          <span
            className="inline-block w-2 h-2 rounded-full"
            style={{ background: col.color }}
          />
          <span className="text-[12.5px] font-semibold text-ink">{col.label}</span>
        </div>
        <span
          className="text-[11px] mono px-1.5 py-0.5 rounded"
          style={{ background: "var(--panel-3)", color: "var(--ink-2)" }}
        >
          {items.length}
        </span>
      </div>
      <div className="p-2 overflow-y-auto flex-1 scroll-thin" style={{ maxHeight: "calc(100vh - 220px)" }}>
        {items.map((a) => (
          <KanbanCard key={a.id} activity={a} />
        ))}
        {items.length === 0 && (
          <div className="text-[11.5px] italic text-ink-3 text-center py-6">
            Vazio
          </div>
        )}
      </div>
    </div>
  );
}
