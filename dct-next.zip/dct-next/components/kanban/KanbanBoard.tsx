"use client";

import { useMemo, useState } from "react";
import { listActivities, listProjects } from "@/lib/data";
import { useUI } from "@/lib/state";
import { KANBAN_COLS } from "@/lib/constants";
import { KanbanColumn } from "./KanbanColumn";
import type { Activity } from "@/types";

export function KanbanBoard() {
  const clientFilter = useUI((s) => s.clientFilter);
  const [tick, setTick] = useState(0);

  const grouped = useMemo(() => {
    const all = listActivities();
    const projs = listProjects();
    const scopedPids = new Set(
      (clientFilter === "all" ? projs : projs.filter((p) => p.clientId === clientFilter)).map((p) => p.id)
    );
    const acts = all.filter((a) => scopedPids.has(a.pid));
    const map: Record<string, Activity[]> = {};
    KANBAN_COLS.forEach((c) => (map[c.id] = []));
    acts.forEach((a) => {
      if (map[a.status]) map[a.status].push(a);
    });
    return map;
    // tick invalidates memo after drop
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clientFilter, tick]);

  return (
    <div className="flex gap-3 overflow-x-auto scroll-thin pb-2">
      {KANBAN_COLS.map((c) => (
        <KanbanColumn
          key={c.id}
          col={c}
          items={grouped[c.id] || []}
          onChange={() => setTick((n) => n + 1)}
        />
      ))}
    </div>
  );
}
