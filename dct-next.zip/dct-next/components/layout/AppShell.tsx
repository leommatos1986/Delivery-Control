import type { ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";
import { ModalHost } from "./ModalHost";
import { DrawerHost } from "./DrawerHost";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="grid grid-cols-[240px_1fr] min-h-screen">
      <Sidebar />
      <div className="flex flex-col min-w-0">
        <Topbar />
        <main className="p-6 max-w-[1800px] w-full">{children}</main>
      </div>
      <ModalHost />
      <DrawerHost />
    </div>
  );
}
