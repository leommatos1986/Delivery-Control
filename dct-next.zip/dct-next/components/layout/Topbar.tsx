"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { listClients } from "@/lib/data";
import { useUI } from "@/lib/state";
import { Icon } from "@/components/ui/Icon";

const CRUMB_MAP: Record<string, string[]> = {
  "/":         ["Home"],
  "/my":       ["Home", "Minhas Atividades"],
  "/kanban":   ["Home", "Kanban"],
  "/hours":    ["Home", "Horas"],
  "/clients":  ["Home", "Clientes"],
  "/projects": ["Home", "Projetos"],
  "/timeline": ["Home", "Cronograma"],
  "/resources":["Home", "Recursos"],
  "/saving":   ["Home", "Schedule & Saving"],
  "/risks":    ["Home", "Riscos"],
  "/issues":   ["Home", "Issues"],
  "/decisions":["Home", "Decisões"],
  "/gov":      ["Home", "Governança"],
  "/reports":  ["Home", "Relatórios"],
  "/admin":    ["Home", "Admin"],
  "/docs":     ["Home", "Arquitetura & Docs"],
};

export function Topbar() {
  const pathname = usePathname();
  const clientFilter = useUI((s) => s.clientFilter);
  const setClientFilter = useUI((s) => s.setClientFilter);
  const clients = listClients();

  const crumbs = CRUMB_MAP[pathname] || CRUMB_MAP["/"];

  // Theme toggle: light / dark
  const [theme, setTheme] = useState<"light" | "dark" | null>(null);
  useEffect(() => {
    const saved = (typeof window !== "undefined" ? localStorage.getItem("dct-theme") : null) as
      | "light" | "dark" | null;
    if (saved) {
      document.documentElement.setAttribute("data-theme", saved);
      setTheme(saved);
    } else {
      setTheme(
        window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
      );
    }
  }, []);
  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    localStorage.setItem("dct-theme", next);
    setTheme(next);
  };

  return (
    <header
      className="sticky top-0 z-10 bg-panel border-b h-14 flex items-center gap-3.5 px-6"
      style={{ borderBottomColor: "var(--border)" }}
    >
      {/* Breadcrumbs */}
      <div className="flex items-center gap-2 text-ink-3 text-[13px]">
        {crumbs.map((c, i) => (
          <span key={i} className="contents">
            {i > 0 && <span className="text-ink-4">/</span>}
            <span className={i === crumbs.length - 1 ? "text-ink font-medium" : ""}>
              {c}
            </span>
          </span>
        ))}
      </div>

      <div className="flex-1" />

      {/* Client filter */}
      <div
        className="flex items-center gap-2 px-3 py-1.5 rounded-2xl text-[12.5px] text-ink-2"
        style={{ background: "var(--panel-3)" }}
      >
        <Icon name="folder" size={12} />
        <span>Cliente</span>
        <select
          value={clientFilter}
          onChange={(e) => setClientFilter(e.target.value)}
          className="bg-transparent border-0 font-medium text-ink cursor-pointer"
        >
          <option value="all">Todos os clientes</option>
          {clients.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      {/* Search */}
      <div
        className="flex items-center gap-2 px-3 py-1.5 rounded-md min-w-[260px] text-ink-3"
        style={{ background: "var(--panel-3)" }}
      >
        <Icon name="search" size={14} strokeWidth={2} />
        <input
          type="text"
          placeholder="Buscar atividades, projetos, consultores…"
          className="bg-transparent border-0 flex-1 text-[13px] outline-none text-ink placeholder:text-ink-3"
        />
      </div>

      {/* Notifications */}
      <button
        title="Notificações"
        className="w-[34px] h-[34px] rounded-md grid place-items-center text-ink-2 relative hover:bg-panel-3 hover:text-ink transition-colors"
      >
        <Icon name="bell" size={16} strokeWidth={1.8} />
        <span
          className="absolute top-0.5 right-0.5 text-white text-[9.5px] font-semibold font-mono px-1 py-px rounded-md leading-none"
          style={{ background: "var(--crit)", border: "2px solid var(--panel)" }}
        >
          7
        </span>
      </button>

      {/* Theme */}
      <button
        title="Alternar tema"
        onClick={toggleTheme}
        className="w-[34px] h-[34px] rounded-md grid place-items-center text-ink-2 hover:bg-panel-3 hover:text-ink transition-colors"
      >
        <Icon name={theme === "dark" ? "sun" : "moon"} size={16} strokeWidth={1.8} />
      </button>

      {/* Help */}
      <button
        title="Ajuda"
        className="w-[34px] h-[34px] rounded-md grid place-items-center text-ink-2 hover:bg-panel-3 hover:text-ink transition-colors"
      >
        <Icon name="help" size={16} strokeWidth={1.8} />
      </button>
    </header>
  );
}
