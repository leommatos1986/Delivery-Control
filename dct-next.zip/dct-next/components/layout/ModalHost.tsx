"use client";

import { useEffect } from "react";
import { useUI } from "@/lib/state";

export function ModalHost() {
  const modalContent = useUI((s) => s.modalContent);
  const closeModal = useUI((s) => s.closeModal);

  useEffect(() => {
    document.body.style.overflow = modalContent ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [modalContent]);

  if (!modalContent) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-6"
      style={{ background: "rgba(15,27,45,.45)" }}
      onClick={(e) => e.target === e.currentTarget && closeModal()}
    >
      <div
        className="bg-panel rounded-[10px] w-full max-w-[640px] max-h-[88vh] overflow-y-auto border"
        style={{ borderColor: "var(--border)", boxShadow: "var(--shadow-lg)" }}
      >
        {modalContent}
      </div>
    </div>
  );
}
