"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import { Icon, type IconName } from "@/components/ui/Icon";

interface NavItem {
  href: string;
  label: string;
  icon: IconName;
  count?: string;
}
interface NavGroup {
  group: string;
  items: NavItem[];
}

const NAV: NavGroup[] = [
  {
    group: "Operação",
    items: [
      { href: "/", label: "Home", icon: "home" },
      { href: "/my", label: "Minhas Atividades", icon: "user", count: "8" },
      { href: "/kanban", label: "Kanban", icon: "kanban" },
      { href: "/hours", label: "Horas", icon: "clock" },
    ],
  },
  {
    group: "Portfólio",
    items: [
      { href: "/clients", label: "Clientes", icon: "building", count: "6" },
      { href: "/projects", label: "Projetos", icon: "folder", count: "7" },
      { href: "/timeline", label: "Cronograma", icon: "calendar" },
      { href: "/resources", label: "Recursos", icon: "users" },
      { href: "/saving", label: "Schedule & Saving", icon: "saving" },
    ],
  },
  {
    group: "Gestão",
    items: [
      { href: "/risks", label: "Riscos", icon: "shield", count: "7" },
      { href: "/issues", label: "Issues", icon: "alert", count: "7" },
      { href: "/decisions", label: "Decisões", icon: "gavel" },
      { href: "/gov", label: "Governança", icon: "target", count: "10" },
      { href: "/reports", label: "Relatórios", icon: "report" },
    ],
  },
  {
    group: "Sistema",
    items: [
      { href: "/admin", label: "Admin", icon: "settings" },
      { href: "/docs", label: "Arquitetura & Docs", icon: "blueprint" },
    ],
  },
];

export function Sidebar() {
  const pathname = usePathname();
  return (
    <aside
      className="bg-panel border-r border-border sticky top-0 h-screen flex flex-col"
      style={{ borderRightColor: "var(--border)" }}
    >
      {/* Brand */}
      <div
        className="flex items-center gap-2.5 px-4 h-14 border-b flex-shrink-0"
        style={{ borderBottomColor: "var(--border)" }}
      >
        <div
          className="w-7 h-7 rounded-md grid place-items-center text-white font-bold font-mono"
          style={{
            background: "linear-gradient(135deg, var(--accent), var(--accent-2))",
            fontSize: 13, letterSpacing: "-.5px",
          }}
        >
          DC
        </div>
        <div className="flex flex-col leading-none overflow-hidden">
          <b className="text-[13.5px] font-semibold text-ink whitespace-nowrap">Delivery Control</b>
          <span className="text-[10.5px] text-ink-3 uppercase tracking-wider whitespace-nowrap">Tower · SAP</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-2 overflow-y-auto flex-1 scroll-thin">
        {NAV.map((g) => (
          <div key={g.group}>
            <div className="text-[10.5px] uppercase tracking-wider text-ink-3 px-3 pt-3.5 pb-1.5 font-medium">
              {g.group}
            </div>
            {g.items.map((it) => {
              const active =
                it.href === "/"
                  ? pathname === "/"
                  : pathname.startsWith(it.href);
              return (
                <Link
                  key={it.href}
                  href={it.href}
                  className={clsx(
                    "flex items-center gap-2.5 px-2.5 py-1.5 rounded-[5px] text-[13px]",
                    "transition-colors relative",
                    active
                      ? "bg-accent-soft text-accent font-medium"
                      : "text-ink-2 hover:bg-panel-3 hover:text-ink"
                  )}
                  style={active ? { color: "var(--accent)" } : undefined}
                >
                  <Icon name={it.icon} size={16} />
                  <span className="flex-1">{it.label}</span>
                  {it.count && (
                    <span
                      className={clsx(
                        "font-mono text-[10.5px] rounded-lg px-1.5 py-px font-medium",
                        active ? "text-white" : "text-ink-2"
                      )}
                      style={{
                        background: active ? "var(--accent)" : "var(--panel-3)",
                      }}
                    >
                      {it.count}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>

      {/* User footer */}
      <div
        className="border-t p-2.5 flex items-center gap-2.5"
        style={{ borderTopColor: "var(--border)" }}
      >
        <div
          className="avatar"
          style={{ background: "linear-gradient(135deg,#1F3A5F,#2E5488)" }}
        >
          LM
        </div>
        <div className="flex flex-col leading-tight overflow-hidden flex-1 min-w-0">
          <b className="text-[12.5px] font-medium truncate">Leo Matos</b>
          <span className="text-[11px] text-ink-3 truncate">Delivery Manager</span>
        </div>
      </div>
    </aside>
  );
}
