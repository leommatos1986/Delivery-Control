"use client";

import { useUI } from "@/lib/state";
import { ActivityDrawer } from "@/components/activity/ActivityDrawer";

export function DrawerHost() {
  const drawerActivityId = useUI((s) => s.drawerActivityId);
  const closeDrawer = useUI((s) => s.closeDrawer);

  if (!drawerActivityId) return null;

  return (
    <>
      <div
        className="fixed inset-0 z-[80]"
        style={{ background: "rgba(15,27,45,.45)" }}
        onClick={closeDrawer}
      />
      <ActivityDrawer activityId={drawerActivityId} />
    </>
  );
}
