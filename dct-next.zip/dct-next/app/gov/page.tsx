"use client";

import { useMemo } from "react";
import { buildGovernanceList } from "@/lib/governance";
import { useUI } from "@/lib/state";
import { Card, CardHeader } from "@/components/ui/Card";
import { GovernanceTop10 } from "@/components/dashboard/GovernanceTop10";

export default function GovernancePage() {
  const clientFilter = useUI((s) => s.clientFilter);
  const items = useMemo(() => buildGovernanceList(clientFilter), [clientFilter]);
  return (
    <>
      <div className="mb-4">
        <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">
          Governance Center
        </h1>
        <p className="text-ink-2 text-[13.5px] m-0">
          {items.length} itens que exigem atenção da gestão neste escopo.
        </p>
      </div>
      <Card>
        <CardHeader title="Top itens" sub="ordenados por severidade e urgência" />
        <GovernanceTop10 items={items.slice(0, 20)} />
      </Card>
    </>
  );
}
