"use client";

import Link from "next/link";
import { useMemo } from "react";
import { listProjects, getClient, getUser } from "@/lib/data";
import { useUI } from "@/lib/state";
import { fmtDate, fmtH } from "@/lib/formatters";
import { Card, CardHeader } from "@/components/ui/Card";
import { HealthChip } from "@/components/ui/HealthChip";
import { PBar } from "@/components/ui/PBar";
import { Avatar } from "@/components/ui/Avatar";

export default function ProjectsPage() {
  const clientFilter = useUI((s) => s.clientFilter);
  const projects = useMemo(() => {
    const all = listProjects();
    return clientFilter === "all" ? all : all.filter((p) => p.clientId === clientFilter);
  }, [clientFilter]);

  return (
    <>
      <div className="mb-4">
        <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">
          Projetos
        </h1>
        <p className="text-ink-2 text-[13.5px] m-0">
          {projects.length} projeto(s) no escopo atual. Clique em um projeto para abrir o detalhe.
        </p>
      </div>

      <Card>
        <CardHeader title="Portfólio" sub="ordenado por health" />
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead>
              <tr>
                <th>Cliente / Projeto</th>
                <th>Tipo</th>
                <th>Fase</th>
                <th>PM</th>
                <th>Progresso</th>
                <th>Horas</th>
                <th>Go-Live</th>
                <th className="center">Health</th>
              </tr>
            </thead>
            <tbody>
              {projects.map((p) => {
                const cl = getClient(p.clientId);
                const pm = getUser(p.pmId);
                return (
                  <tr key={p.id}>
                    <td className="cell-primary">
                      <div className="mono txt-mut" style={{ fontSize: 11 }}>
                        {cl?.name}
                      </div>
                      <Link href={`/projects/${p.id}`}>{p.name}</Link>
                    </td>
                    <td>{p.type}</td>
                    <td>{p.phase}</td>
                    <td><Avatar user={pm} size={22} /></td>
                    <td><PBar value={p.progress} /></td>
                    <td className="cell-mono">
                      {fmtH(p.actualHours)}
                      <span className="txt-mut">/{fmtH(p.plannedHours)}</span>
                    </td>
                    <td className="mono text-[11.5px]">{fmtDate(p.goLive)}</td>
                    <td className="center"><HealthChip health={p.health} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}
