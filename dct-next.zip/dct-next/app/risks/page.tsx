"use client";

import { listRisks, getUser, getProject, getClient } from "@/lib/data";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { fmtDate } from "@/lib/formatters";

export default function RisksPage() {
  const risks = listRisks();
  return (
    <>
      <div className="mb-4">
        <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">Risk Register</h1>
        <p className="text-ink-2 text-[13.5px] m-0">{risks.length} riscos ativos no portfólio.</p>
      </div>
      <Card>
        <CardHeader title="Riscos" sub="ordenado por severidade" />
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead>
              <tr>
                <th>ID</th>
                <th>Cliente / Projeto</th>
                <th>Risco</th>
                <th>Sev</th>
                <th>Prob × Impacto</th>
                <th>Owner</th>
                <th>Due</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {risks.map((r) => {
                const proj = getProject(r.pid);
                const cl = proj && getClient(proj.clientId);
                const owner = getUser(r.ownerId);
                return (
                  <tr key={r.id}>
                    <td className="mono text-[11.5px]">{r.id}</td>
                    <td className="text-[12px]"><span className="txt-mut">{cl?.name}</span><br />{proj?.name}</td>
                    <td className="cell-primary">{r.title}</td>
                    <td>
                      <Badge variant={r.sev === "Critical" ? "crit" : r.sev === "High" ? "warn" : "info"}>{r.sev}</Badge>
                    </td>
                    <td className="mono text-[11.5px]">{r.prob} × {r.impact}</td>
                    <td>{owner?.name || "—"}</td>
                    <td className="mono text-[11.5px]">{fmtDate(r.due)}</td>
                    <td>{r.status}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}
