import { PlaceholderView } from "@/components/ui/PlaceholderView";

export default function MyPage() {
  return (
    <PlaceholderView
      title="Minhas Atividades"
      desc="Workspace do consultor — atividades atribuídas ao usuário logado."
      bullets={[
        "Fila priorizada (atrasadas → vencendo hoje → semana → demais).",
        "Timer/apontamento inline de horas quando move para In Progress.",
        "Ações rápidas: iniciar, concluir, bloquear, aguardar cliente.",
        "Filtros por projeto, fase, sessão, prioridade.",
      ]}
    />
  );
}
