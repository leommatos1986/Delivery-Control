import { PlaceholderView } from "@/components/ui/PlaceholderView";

export default function ReportsPage() {
  return (
    <PlaceholderView
      title="Relatórios"
      desc="Status Reports executivos e exportações consolidadas."
      bullets={[
        'Botão "Gerar Status Report" com Executive Summary por projeto.',
        "Comparativo semana atual × semana anterior.",
        "Export Excel/PDF/PowerPoint do portfólio.",
        "Templates de relatório configuráveis pelo PMO.",
      ]}
    />
  );
}
