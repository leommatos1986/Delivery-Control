import { PlaceholderView } from "@/components/ui/PlaceholderView";

export default function TimelinePage() {
  return (
    <PlaceholderView
      title="Cronograma"
      desc="Timeline consolidada de fases, milestones e Go-Lives dos projetos."
      bullets={[
        "Gantt simplificado por projeto e fase (SAP Activate).",
        "Milestones críticos (Kick-off, SIT, UAT, Cutover, Go-Live, Hypercare).",
        "Highlight de milestones em risco e atrasos.",
        "Edição de datas com validação de dependências.",
      ]}
    />
  );
}
