import { PlaceholderView } from "@/components/ui/PlaceholderView";

export default function AdminPage() {
  return (
    <PlaceholderView
      title="Admin"
      desc="Configurações de sistema — usuários, clientes, templates e workflows."
      bullets={[
        "CRUD de usuários (com role, capacidade, taxa horária).",
        "CRUD de clientes.",
        "Templates de projeto (Public Cloud, AMS, Roll-out).",
        "Workflow rules (auto-release, alertas, atribuições).",
        "Parâmetros do sistema (fase padrão, moeda, timezone).",
      ]}
    />
  );
}
