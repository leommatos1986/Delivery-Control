"use client";

import { internalUsers, safeUtilPct } from "@/lib/data";
import { Card, CardHeader } from "@/components/ui/Card";
import { Avatar } from "@/components/ui/Avatar";
import { PBar } from "@/components/ui/PBar";

export default function ResourcesPage() {
  const users = internalUsers();
  return (
    <>
      <div className="mb-4">
        <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">Recursos</h1>
        <p className="text-ink-2 text-[13.5px] m-0">
          Capacidade × alocação — {users.length} consultores internos.
        </p>
      </div>
      <Card>
        <CardHeader title="Utilização da equipe" sub="mês corrente" />
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead>
              <tr>
                <th>Consultor</th>
                <th>Role</th>
                <th className="right">Capacidade</th>
                <th className="right">Planejado</th>
                <th className="right">Realizado</th>
                <th>Utilização</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => {
                const pct = Math.round(safeUtilPct(u) * 100);
                return (
                  <tr key={u.id}>
                    <td className="cell-primary">
                      <div className="flex items-center gap-2">
                        <Avatar user={u} size={24} />
                        <span>{u.name}</span>
                      </div>
                    </td>
                    <td>{u.role}</td>
                    <td className="cell-mono">{u.cap}h</td>
                    <td className="cell-mono">{u.planned}h</td>
                    <td className="cell-mono">{u.actual}h</td>
                    <td style={{ minWidth: 140 }}>
                      <PBar value={pct} tone={pct > 100 ? "crit" : pct > 85 ? "warn" : "good"} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}
