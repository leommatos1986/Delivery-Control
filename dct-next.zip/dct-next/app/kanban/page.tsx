import { KanbanBoard } from "@/components/kanban/KanbanBoard";

export default function KanbanPage() {
  return (
    <>
      <div className="mb-4">
        <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">Kanban</h1>
        <p className="text-ink-2 text-[13.5px] m-0">
          Fluxo operacional — arraste os cards entre colunas. Concluir uma atividade
          libera automaticamente as dependentes (Ready).
        </p>
      </div>
      <KanbanBoard />
    </>
  );
}
