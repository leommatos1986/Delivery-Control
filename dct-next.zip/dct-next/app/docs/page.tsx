import { PlaceholderView } from "@/components/ui/PlaceholderView";

export default function DocsPage() {
  return (
    <PlaceholderView
      title="Arquitetura & Docs"
      desc="Documentação viva da solução — modelo de dados, workflows, permissões."
      bullets={[
        "Diagrama funcional (Home / Kanban / RAID / Governance).",
        "Modelo de dados (entidades e relacionamentos).",
        "Fluxos automatizados (auto-release, notificações, escalação).",
        "Matriz de permissões por perfil.",
        "Roadmap por versão (MVP → v1 → v2).",
      ]}
    />
  );
}
