import { HomeView } from "@/components/dashboard/HomeView";

export default function HomePage() {
  return <HomeView />;
}
