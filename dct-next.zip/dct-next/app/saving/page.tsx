import { PlaceholderView } from "@/components/ui/PlaceholderView";

export default function SavingPage() {
  return (
    <PlaceholderView
      title="Schedule & Saving"
      desc="Alocação de recursos e cálculo de saving (horas economizadas × custo blended)."
      bullets={[
        "Schedule consolidado consultor × semana × projeto.",
        "Saving por projeto (delta planejado − realizado, valorizado por hora blend).",
        "Simulador de contratação/desligamento.",
        "Export executivo em PPTX/Excel.",
      ]}
    />
  );
}
