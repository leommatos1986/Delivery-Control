import type { Metadata } from "next";
import "./globals.css";
import { AppShell } from "@/components/layout/AppShell";

export const metadata: Metadata = {
  title: "Delivery Control Tower",
  description:
    "Gestão de Delivery para consultoria SAP — portfolio, projetos, RAID, horas e forecast financeiro",
};

// Fonts are loaded via <link> tags rather than next/font/google so the
// project builds and runs the same way offline, in locked-down CI, and on
// Vercel. When you want zero-CLS preloading, swap this for `next/font/google`
// — the CSS variables `--font-sans` / `--font-mono` already flow through
// Tailwind's `font-sans`/`font-mono` utilities.
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
