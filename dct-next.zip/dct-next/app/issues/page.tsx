"use client";

import { listIssues, getUser, getProject, getClient } from "@/lib/data";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { fmtDate } from "@/lib/formatters";

export default function IssuesPage() {
  const issues = listIssues();
  return (
    <>
      <div className="mb-4">
        <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">Issues</h1>
        <p className="text-ink-2 text-[13.5px] m-0">{issues.length} issues ativas no portfólio.</p>
      </div>
      <Card>
        <CardHeader title="Issue Management" sub="ordenado por severidade" />
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead>
              <tr>
                <th>ID</th>
                <th>Cliente / Projeto</th>
                <th>Issue</th>
                <th>Sev</th>
                <th>Owner</th>
                <th>Due</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {issues.map((i) => {
                const proj = getProject(i.pid);
                const cl = proj && getClient(proj.clientId);
                const owner = getUser(i.ownerId);
                return (
                  <tr key={i.id}>
                    <td className="mono text-[11.5px]">{i.id}</td>
                    <td className="text-[12px]"><span className="txt-mut">{cl?.name}</span><br />{proj?.name}</td>
                    <td className="cell-primary">{i.title}</td>
                    <td>
                      <Badge variant={i.sev === "Critical" ? "crit" : i.sev === "High" ? "warn" : "info"}>{i.sev}</Badge>
                    </td>
                    <td>{owner?.name || "—"}</td>
                    <td className="mono text-[11.5px]">{fmtDate(i.due)}</td>
                    <td>{i.status}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}
