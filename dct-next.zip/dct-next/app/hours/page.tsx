import { PlaceholderView } from "@/components/ui/PlaceholderView";

export default function HoursPage() {
  return (
    <PlaceholderView
      title="Horas"
      desc="Apontamento, análise de eficiência e burn-rate por projeto."
      bullets={[
        "Timesheet semanal (grid por consultor × dia × atividade).",
        "Comparativo planejado × realizado por projeto/sessão.",
        "Indicadores: efficiency, burn-rate, forecast, variance.",
        "Export para Excel de todos os apontamentos.",
      ]}
    />
  );
}
