"use client";

import { listClients, listProjectsByClient } from "@/lib/data";
import { Card, CardHeader, CardBody } from "@/components/ui/Card";
import { HealthChip } from "@/components/ui/HealthChip";
import Link from "next/link";

export default function ClientsPage() {
  const clients = listClients();
  return (
    <>
      <div className="mb-4">
        <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">Clientes</h1>
        <p className="text-ink-2 text-[13.5px] m-0">{clients.length} clientes ativos no portfólio.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {clients.map((c) => {
          const projs = listProjectsByClient(c.id);
          return (
            <Card key={c.id}>
              <CardHeader title={c.name} sub={c.industry} />
              <CardBody>
                <div className="text-[12.5px] text-ink-2 mb-2">
                  <b className="text-ink">{projs.length}</b> projeto(s)
                </div>
                <div className="space-y-1.5">
                  {projs.map((p) => (
                    <div key={p.id} className="flex items-center justify-between text-[12px]">
                      <Link href={`/projects/${p.id}`} className="text-accent hover:underline flex-1 truncate">
                        {p.name}
                      </Link>
                      <HealthChip health={p.health} />
                    </div>
                  ))}
                </div>
              </CardBody>
            </Card>
          );
        })}
      </div>
    </>
  );
}
