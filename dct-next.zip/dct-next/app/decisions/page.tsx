"use client";

import { listDecisions, getUser, getProject, getClient } from "@/lib/data";
import { Card, CardHeader } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { fmtDate } from "@/lib/formatters";

export default function DecisionsPage() {
  const decisions = listDecisions();
  return (
    <>
      <div className="mb-4">
        <h1 className="m-0 mb-1 text-[22px] font-semibold tracking-tight text-ink">Decision Log</h1>
        <p className="text-ink-2 text-[13.5px] m-0">{decisions.length} decisões registradas.</p>
      </div>
      <Card>
        <CardHeader title="Decisões" />
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead>
              <tr>
                <th>ID</th>
                <th>Data</th>
                <th>Cliente / Projeto</th>
                <th>Decisão</th>
                <th>Categoria</th>
                <th>Owner</th>
                <th>Status</th>
                <th>Aprovada por</th>
              </tr>
            </thead>
            <tbody>
              {decisions.map((d) => {
                const proj = getProject(d.pid);
                const cl = proj && getClient(proj.clientId);
                const owner = getUser(d.ownerId);
                const approver = d.approvedBy ? getUser(d.approvedBy) : null;
                return (
                  <tr key={d.id}>
                    <td className="mono text-[11.5px]">{d.id}</td>
                    <td className="mono text-[11.5px]">{fmtDate(d.date)}</td>
                    <td className="text-[12px]"><span className="txt-mut">{cl?.name}</span><br />{proj?.name}</td>
                    <td className="cell-primary">{d.title}</td>
                    <td>{d.category || "—"}</td>
                    <td>{owner?.name || "—"}</td>
                    <td>
                      <Badge variant={d.status === "Approved" ? "good" : d.status === "Rejected" ? "crit" : "info"}>
                        {d.status || "—"}
                      </Badge>
                    </td>
                    <td>{approver?.name || "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}
