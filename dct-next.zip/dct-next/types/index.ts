/**
 * =========================================================================
 * Delivery Control Tower — domain types
 * =========================================================================
 * Every entity of the system, typed. All persistence goes through the
 * functions in /lib/data — components never import raw arrays.
 * When Supabase is added, only /lib/data changes; these types stay.
 */

// ---------- Common enums ------------------------------------------------
export type Health = "on" | "att" | "risk" | "crit";
export type Priority = "Alta" | "Média" | "Baixa";
export type Severity = "Low" | "Medium" | "High" | "Critical";
export type ActivateePhase =
  | "Discover"
  | "Prepare"
  | "Explore"
  | "Realize"
  | "Deploy"
  | "Run";

export type ActivityStatus =
  | "backlog"
  | "ready"
  | "inprog"
  | "blocked"
  | "wclient"
  | "review"
  | "done";

export type ProjectType =
  | "Implementação"
  | "AMS/Melhoria"
  | "Roll-out"
  | "Discovery";

// ---------- User --------------------------------------------------------
export interface User {
  id: string;
  name: string;
  role: string;
  init: string;
  hue: number;
  cap: number;
  planned: number;
  actual: number;
  email?: string;
  external?: boolean;
  status?: "active" | "inactive";
}

// ---------- Client ------------------------------------------------------
export interface Contact {
  name: string;
  email: string;
  phone: string;
}
export interface ClientEnrichment {
  industry: string;
  market: string;
  size: string;
  employees: number;
  revenue: number;
  revenueUnit: string;
  services: string;
  hq: string;
  founded: number;
  website: string;
  profile: string;
  enrichedAt: Date;
}
export interface Client {
  id: string;
  name: string;
  industry: string;
  logo: string;
  regDate?: string;
  site?: string;
  contacts?: { comercial: Contact; ponto: Contact; fin: Contact };
  enrichment?: ClientEnrichment;
  createdByUser?: boolean;
}

// ---------- Project -----------------------------------------------------
export interface ProjectDoc {
  name: string;
  type: string;
  size: string;
  who: string;
  ts: Date;
  blob?: Blob | File;
  mime?: string;
  kind?: "proposta" | "dda" | string;
}
export interface Project {
  id: string;
  clientId: string;
  name: string;
  type: ProjectType | string;
  phase: string;
  pmId: string;
  startDate: string;
  endDate: string;
  goLive: string;
  health: Health;
  progress: number;
  plannedHours: number;
  actualHours: number;
  activitiesTotal: number;
  activitiesDone: number;
  activitiesLate: number;
  risks: number;
  issues: number;
  milestonesRisk: number;
  description?: string;
  docs?: ProjectDoc[];
}

// ---------- Activity ----------------------------------------------------
export interface Activity {
  id: string;
  pid: string;
  phase: string;
  session: string;
  name: string;
  ownerId: string;
  status: ActivityStatus;
  prio: Priority;
  due: string;
  plH: number;
  acH: number;
  deps: string[];
}

// Rich detail (comments/history/hours/subacts/attachments/audit) — lazy loaded.
export interface Subactivity {
  id: string;
  text: string;
  done: boolean;
  who: string;
}
export interface Comment {
  who: string;
  txt: string;
  ts: Date;
}
export interface HistoryEntry {
  from: ActivityStatus | null;
  to: ActivityStatus;
  by: string;
  ts: Date;
  note: string;
}
export interface AuditEntry {
  who: string;
  action: string;
  ts: Date;
  field?: string;
  old?: string | number;
  new?: string | number;
}
export interface HourEntry {
  date: string;
  hours: number;
  tipo: string;
  desc: string;
  who: string;
}
export interface Attachment {
  name: string;
  type: string;
  size: string;
  who: string;
  ts: Date;
  blob?: Blob | File;
  mime?: string;
  generated?: boolean;
}
export interface ActivityDetail {
  subacts: Subactivity[];
  comments: Comment[];
  history: HistoryEntry[];
  audit: AuditEntry[];
  hourEntries: HourEntry[];
  attachments: Attachment[];
}

// ---------- RAID + Milestones ------------------------------------------
export type RiskStrategy = "Avoid" | "Transfer" | "Mitigate" | "Accept";

export interface Risk {
  id: string;
  pid: string;
  title: string;
  prob: "Baixa" | "Média" | "Alta";
  impact: "Baixo" | "Médio" | "Alto";
  sev: Severity;
  ownerId: string;
  due: string;
  status: string;
  plan?: string;
  category?: string;
  activatePhase?: ActivateePhase;
  activityRef?: string | null;
  strategy?: RiskStrategy;
  description?: string;
  mitigationSteps?: string[];
  contingency?: string;
  earlyWarning?: string;
  impactAreas?: string[];
  review?: string;
  lastReview?: string;
  ai?: boolean;
}

export interface Issue {
  id: string;
  pid: string;
  title: string;
  sev: Severity;
  ownerId: string;
  due: string;
  status: string;
  related?: string;
  priority?: "P1" | "P2" | "P3" | "P4";
  category?: string;
  activatePhase?: ActivateePhase;
  description?: string;
  rootCause?: string;
  workaround?: string;
  resolution?: string;
  impactAreas?: string[];
  escalatedTo?: string;
  createdAt?: string;
  relatedRiskId?: string;
}

export interface DecisionImpact {
  scope: string;
  schedule: string;
  cost: string;
  quality: string;
}
export interface Decision {
  id: string;
  pid: string;
  date: string;
  title: string;
  ownerId: string;
  context?: string;
  outcome?: string;
  category?: string;
  activatePhase?: ActivateePhase;
  status?: "Draft" | "Pending" | "Approved" | "Rejected" | "Superseded";
  approvedBy?: string;
  dueImpact?: string;
  reversibility?: "Reversible" | "Irreversible";
  optionsEvaluated?: string[];
  impactAreas?: DecisionImpact;
  linkedActivities?: string[];
  linkedRisks?: string[];
  linkedIssues?: string[];
}

export interface Milestone {
  id: string;
  pid: string;
  name: string;
  planned: string;
  actual: string;
  status: "planned" | "inprog" | "risk" | "done";
}

// ---------- Templates & Workflows --------------------------------------
export interface TemplateActivity {
  name: string;
  h: number;
  prio: Priority;
}
export interface TemplateSession {
  name: string;
  acts: TemplateActivity[];
}
export interface TemplatePhase {
  name: string;
  pctDuration: number;
  sessions: TemplateSession[];
}
export interface Template {
  id: string;
  name: string;
  desc: string;
  type: ProjectType | string;
  durationMonths: number;
  totalHours: number;
  phases: TemplatePhase[];
}

export interface WorkflowRule {
  id: string;
  name: string;
  cond: string;
  then: string;
  enabled: boolean;
  category: string;
}

// ---------- Notification -----------------------------------------------
export interface Notification {
  id: string;
  ts: string;
  level: "info" | "warn" | "crit" | "good";
  text: string;
}

// ---------- Filter state ------------------------------------------------
export interface FilterState {
  pm: string | null;
  consultor: string | null;
  phase: string | null;
  session: string | null;
  status: string | null;
  priority: string | null;
  period: "overdue" | "today" | "week" | "month" | null;
}

// ---------- Kanban columns ----------------------------------------------
export interface KanbanColumn {
  id: ActivityStatus;
  label: string;
  color: string;
}

// ---------- Report / Save shape ----------------------------------------
export interface Report {
  id: string;
  pid: string;
  generatedAt: Date;
  title: string;
  content: string;
}
